function stats = statis(NN_f,NN_itr,NN_time,NN_gfeas)

stats.aver_f=mean(NN_f);
stats.std_f=std(NN_f);

stats.aver_itr=mean(NN_itr);
stats.std_itr=std(NN_itr);

stats.aver_time=mean(NN_time);
stats.std_time=std(NN_time);

stats.aver_gfeas=mean(NN_gfeas);
stats.std_gfeas=std(NN_gfeas);

stats.aver_conse=mean(NN_conse);
stats.std_conse=std(NN_conse);

stats.aver_T=mean(NN_T);
stats.std_T=std(NN_T);
end