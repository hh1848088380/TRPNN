function grad = oscalGf(x,smstep)
    x_len=length(x);
    grad=zeros(x_len,1);
    for i=1:x_len
        xp=x; xm=x;
        xp(i)=x(i)+smstep;
        xm(i)=x(i)-smstep                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ;
        grad(i)=(oscalf(xp)-oscalf(xm))/(2*smstep);
    end
end

