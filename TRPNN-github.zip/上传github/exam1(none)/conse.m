function out = conse(x)

X1=x([1,3,5]);
X2=x([2,4,6]);

out=sqrt(std(X1)^2+std(X2)^2);

end