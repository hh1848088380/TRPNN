function f = oscalf(x)
    x1=x(1); x2=x(2);
    f=cos(x1)*sin(x2)-x1/(1+x2^2);
end

