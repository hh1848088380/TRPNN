function [f_val, z_val, time, itr] = compare_fun(method,z0)
global ODE_para dim_x dim_l dim_m ode_result APNN_para;
tspan = ODE_para.tspan;
epsilon = ODE_para.epsilon;

timeout=unifrnd(60,65,1);

tic;
switch method
    case 'TRPNN'
        [z_val, itr] = TRPNN(z0);
    case 'RNN14'
        [z_val, itr] = RNN14(z0);
    case 'RNN15'
        [z_val, itr] = RNN15(z0);
    case {'RNN11'}
        sqz = [z0(1:dim_x); zeros(dim_x,1); z0(dim_x+1:end);];
        [z_val, sqtime]= TEST_TwoTimescale_Nonvex(sqz);
        itr=nan;
    case {'RNN10', 'RNN12', 'RNN13', 'RNN7'}
        if strcmp(method, 'RNN10')
            tspan = 1 * tspan;
        end
        if strcmp(method, 'RNN13') 
            z0 = [z0; rands(dim_x,1)];
        end
        if strcmp(method, 'RNN7')
            z0 = z0(1:dim_x);
        end
        ode_result = [];
        op = odeset('Events', @(t,z) eventfun(t, z, epsilon));
        [t, ode_z] = ode45_timeout(tspan, z0, op, timeout, method);
        z_val=ode_z(end,:)';
        itr=nan;
end
time=toc;

switch method
    case {'RNN13'}
        z_val=z_val(1:dim_x);

    case {'RNN11'}
        time=sqtime;
        

    case {'RNN7'}
        z_val=[z_val];

end




f_val=oscalf(z_val(1:dim_x));

end

