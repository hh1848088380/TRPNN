clear;
clc;
close all;
warning off;
global ode_result dim_x dim_l xl xu RNN14_para TRU_para ODE_para epsilon;

ode_result=[];

num_pso=[1];%NN
M=1;%M
Moto=1;%随机次数

dim_x=2;
dim_l=2;

xl= [2,2]'; %约束下限
xu= [6,6]'; %约束上限


RNN14_para.MaxIter=50000;
RNN14_para.h=0.0005;
RNN14_para.r=RNN14_para.h/2;
% APNN_para.theta=0.01;%0.01
RNN14_para.theta=0.01;%0.01
RNN14_para.alpha=1;%1
RNN14_para.pro=2;
RNN14_para.inta=0.002;%0.002

TRU_para.MaxIter=2000;
TRU_para.alpha=5;
TRU_para.dta=1;
TRU_para.dtamax=10;
TRU_para.eta1=0.25;
TRU_para.eta2=0.75;
TRU_para.gma1=0.5;
TRU_para.gma2=2;


ODE_para.tspan=[0 100]; %ode时间
ODE_para.sigma1=0.5;
ODE_para.sigma2=0.25;
ODE_para.alpha=0.1;
ODE_para.c=10;
ODE_para.pl=1;
ODE_para.epsilon=1e-5;
ODE_para.sigma2sq=2;
ODE_para.sigma2sq=1;
ODE_para.arg_para=1;

methods= {'TRPNN','RNN7','RNN10','RNN11','RNN12','RNN13','RNN14','RNN15'};

for np=1:length(num_pso)
    NN=num_pso(np);
    rng('shuffle');
    init=unifrnd(-500,500,dim_x+dim_l,NN,Moto);
    init(dim_x+1:end,:,:)=0;
    for i=1:Moto
%         disp(['i=',num2str(i),';N=',num2str(NN),';M=',num2str(M)]);
        initt=init(:,:,i);
        for j=1:numel(methods)
            if NN==1
                [f_val, z_val, time, itr] = compare_fun(methods{j}, initt); %z是组合变量
                disp([methods{j},'-i=',num2str(i),';N=',num2str(NN)]);
            else
                [f_val, z_val, time, itr] = CNO_FUN(methods{j}, M, initt,i,NN);
            end
            eval([methods{j} '_x(:,i) = z_val(1:dim_x);']);
            eval([methods{j} '_f(i) = f_val;']);
            eval([methods{j} '_time(i) = time;']);
            if j==1 || j==2
                eval([methods{j} '_itr(i) = itr;']);
            end
        end
    end
end
disp('finish');
