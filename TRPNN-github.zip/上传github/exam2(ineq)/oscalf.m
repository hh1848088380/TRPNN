function f = oscalf(x)
    x1=x(1); x2=x(2);
    f=-(1/10)*x1^2+(1/60)*x2^3-(1/5)*x1-4*x2;
end

