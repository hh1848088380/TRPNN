function [f_val, z_val, time, itr] = compare_fun(method,z0)
global ODE_para dim_x dim_l ode_result;
tspan = ODE_para.tspan;
epsilon = ODE_para.epsilon;
timeout=60;
tic;
switch method
    case 'TRPNN'
        [z_val, itr] = TRPNN(z0);
    case 'RNN14'
        [z_val, itr] = RNN10(z0);
    case 'RNN15'
        [z_val, itr] = RNN11(z0);
    case {'RNN11'}
        sqz = [z0(1:dim_x); zeros(dim_x,1); zeros(dim_l,1)];
%         [z_val, sqtime]= TEST_TwoTimescale_Nonvex(sqz);
        [z_val, sqtime]= TEST_TwoTimescale_Nonvex();
        itr=nan;
    case {'RNN7','RNN10', 'RNN12', 'RNN13'}
        if strcmp(method, 'RNN10')
            tspan = 1 * tspan;
        end
        if strcmp(method, 'RNN11') || strcmp(method, 'RNN13')
            z0 = [z0; rands(dim_x,1)];
        end
        if strcmp(method, 'RNN7')
            z0 = z0(1:dim_x);
        end
        ode_result = [];
        op = odeset('Events', @(t,z) eventfun(t, z, epsilon));
        [t, ode_z] = ode45_timeout(tspan, z0, op, timeout, method);
%         [t, ode_z] = ode45(@(t,z) ODEPNN(t, z, method), tspan, z0, op);
        z_val=ode_z(end,:)';
        itr=nan;
end
time=toc;

switch method
    case {'RNN12'}
        z_val=z_val(1:dim_x+dim_l);

    case {'RNN11'}
        time=sqtime;
        z_val=[z_val;zeros(dim_l,1)];

    case {'RNN7'}
        z_val=[z_val;zeros(dim_l,1)];

end




f_val=oscalf(z_val(1:dim_x));

end

