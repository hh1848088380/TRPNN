function g = oscalg(x)

    x5=x(5); x6=x(6);
    g1=sqrt(x5)+sqrt(x6)-4;
    g=[g1]';

end