clear;
clc;
close all;
warning off;
format long;
global ode_result dim_x dim_l dim_m xl xu APNN_para TRU_para ODE_para epsilon;

ode_result=[];

num_pso=[6];%NN
M=4;%M
Moto=50;%随机次数
dim_x=6;
dim_l=1;
dim_m=4;

xl= [0,0,0,0,1e-5,1e-5]'; %约束下限
xu= [1,1,1,1,16,16]'; %约束上限


APNN_para.MaxIter=50000;
APNN_para.h=0.001;
APNN_para.r=APNN_para.h/2;
% APNN_para.theta=0.01;%0.01
APNN_para.theta=0.00;%DPNN
APNN_para.alpha=1000;%0.2
APNN_para.beta=1000;%0.2
APNN_para.pro=2;
APNN_para.inta=0.002;%0.002

TRU_para.MaxIter=1000;
TRU_para.alpha=10;
TRU_para.beta=20;
TRU_para.dta=0.1;
TRU_para.dtamax=1;
TRU_para.eta1=0.25;
TRU_para.eta2=0.75;
TRU_para.gma1=0.5;
TRU_para.gma2=2;
TRU_para.sh=0.5;

ODE_para.tspan=[0 100]; %ode时间
ODE_para.sigma1=0.5;%tt=0.5
ODE_para.sigma2=0.003;%tt=0.003
ODE_para.alpha=100;
ODE_para.beta=500;
ODE_para.c=0.1;
ODE_para.pl=0.5;
ODE_para.epsilon=1e-5;
ODE_para.sigma2sq=100;
ODE_para.arg=0.05;

% methods= {'APNN','argPNN','ttPNN','mmPNN','onePNN'};
% methods= {'sqPNN'};
% load('TRU_Exam4_N6M4.mat');
methods= {'trustPNN'};
for np=1:length(num_pso)
    NN=num_pso(np);
%     load('cor_20-39MMPNN_Exam2_N6.mat', 'init'); 
    rng('shuffle');
    init=unifrnd(0.9,0.92,dim_x+dim_l+dim_m,NN,Moto);
%     init(dim_x+1:end,:,:)=0;
    for i=1:Moto
        initt=init(:,:,i);
        for j=1:numel(methods)
            if NN==1
                [f_val, z_val, time, itr] = compare_fun(methods{j}, initt); %z是组合变量
                disp([methods{j},'-i=',num2str(i),';N=',num2str(NN)]);
            else
                [f_val, z_val, time, itr] = CNO_FUN(methods{j}, M, initt,i,NN);
            end
            f_val
            eval([methods{j} '_x(:,i) = z_val(1:dim_x);']);
            eval([methods{j} '_f(i) = f_val;']);
            eval([methods{j} '_time(i) = time;']);
            if j==1 || j==2
                eval([methods{j} '_itr(i) = itr;']);
            end
        end
        str=['DNN_Exam2_','N',num2str(NN),'M',num2str(M)];
        save(str);
    end

    save(str);
%     clear init;

end
disp('finish');
