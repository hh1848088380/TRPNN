function Hs = oscalHess(x, smstep)
    x_len=length(x);
    H=zeros(x_len);
    for i=1:x_len
        xp=x; xm=x;
        xp(i)=x(i)+smstep;
        xm(i)=x(i)-smstep;
        H(:,i)=(oscalGf(xp,smstep)-oscalGf(xm,smstep))/(2*smstep);
    end
    Hs=(H+H')/2;
end