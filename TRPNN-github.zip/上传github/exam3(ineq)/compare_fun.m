function [f_val, z_val, time, itr] = compare_fun(method,z0)
global ODE_para dim_x dim_l ode_result;
tspan = ODE_para.tspan;
epsilon = ODE_para.epsilon;

timeout=60;

tic;
switch method
    case 'TRPNN'
        [z_val, itr] = TRPNN(z0);
    case 'RNN10'
        [z_val, itr] = RNN10(z0);
    case 'RNN11'
        [z_val, itr] = RNN11(z0);
    case {'RNN7'}
        sqz = [z0(1:dim_x); zeros(dim_x,1); zeros(dim_l,1)];
        [z_val, sqtime]= TEST_TwoTimescale_Nonvex();
        itr=nan;
    case {'RNN5', 'RNN6', 'RNN8', 'RNN9'}
        if strcmp(method, 'RNN6')
            tspan = 1 * tspan;
        end
        if strcmp(method, 'RNN9') || strcmp(method, 'RNN7')
            z0 = [z0; rands(dim_x,1)];
        end
        if strcmp(method, 'RNN5')
            z0 = z0(1:dim_x);
        end
        ode_result = [];
        op = odeset('Events', @(t,z) eventfun(t, z, epsilon));
        [t, ode_z] = ode45_timeout(tspan, z0, op, timeout, method);
%         [t, ode_z] = ode45(@(t,z) ODEPNN(t, z, method), tspan, z0, op);
        z_val=ode_z(end,:)';
        itr=nan;
end
time=toc;

switch method
    case {'RNN9'}
        z_val=z_val(1:dim_x+dim_l);

    case {'RNN7'}
        time=sqtime;
        z_val=[z_val;zeros(dim_l,1)];

    case {'RNN5'}
        z_val=[z_val;zeros(dim_l,1)];

end




f_val=oscalf(z_val(1:dim_x))

end

