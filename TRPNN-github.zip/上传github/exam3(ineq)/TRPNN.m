function [output,k] = trustPNN(z0)
global TRU_para xl xu dim_x dim_l;
xk=z0(1:dim_x);
lamk=z0(dim_x+1:dim_x+dim_l);

MaxIter=TRU_para.MaxIter;
alpha=TRU_para.alpha;
dta=TRU_para.dta;
dtamax=TRU_para.dtamax;
eta1=TRU_para.eta1;
eta2=TRU_para.eta2;
gma1=TRU_para.gma1;
gma2=TRU_para.gma2; 


k=1;
cou=0;
err=1e-2; smstep=1e-6;
while(k<MaxIter)
    %计算函数值和梯度
    store_x(:,k)=xk;
    store_lam(:,k)=lamk;

    fk=oscalf(xk);  store_fk(k)=fk;
    gk=oscalg(xk);  store_gk(:,k)=gk;

    Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;
    Ggk=oscalGg(xk,smstep);  store_Ggk(:,:,k)=Ggk;

    HsumgGg=zeros(length(xk));
    HHsumgGg=zeros(length(xk));
    for i=1:length(gk)
        gGgk(:,i)=lamk(i)^2*gk(i)*Ggk(:,i);%一阶梯度

        HgGgk(:,:,i)=lamk(i)^2*Ggk(:,i)*Ggk(:,i)';%二阶梯度
        HsumgGg=HsumgGg+HgGgk(:,:,i);

        GGH=oscalGHess(xk,smstep);    
        GGHk(:,:,i)=lamk(i)^2*gk(i)*GGH{i};
        HHsumgGg=HHsumgGg+GGHk(:,:,i);
    end

    Glk=Gfk+Ggk*lamk+alpha*sum(gGgk,2); store_Glk(:,k)=Glk;

%     Bk=oscalHess(xk,smstep)+alpha*(HsumgGg+HHsumgGg);
    Bk=oscalHess(xk,smstep)+alpha*(HsumgGg);
    %狗腿法求解二次近似子问题
    dk=dogleg(Glk,Bk,dta);
    store_dk(:,k)=dk;

    %投影约束
    pro_dk=-xk+xpro(xk+dk,xl,xu);
    store_pro_dk(:,k)=pro_dk;


    pro_gk=-xk+xpro(xk-Glk,xl,xu);
    store_pro_gk(:,k)=pro_gk;

    t=1;
    dtr=t*pro_dk+(1-t)*pro_gk;
    store_dtr(:,k)=dtr;

    %判断终止条件
%     if (norm(dtr)<err  && norm(gk)<1e-5)
%         break;
%     end
    if (norm(dtr)<err  && norm(gk)<1e-5)
        disp('succ');
        break;
    end
    %计算下降效果
%     deltaq = -(Glk'*dtr+0.5*dtr'*Bk*dtr);
%     oscalL = oscalf(xk)+ lamk'*oscalg(xk) + alpha*0.5*sum((lamk.*oscalg(xk)).^2);
%     oscalLd = oscalf(xk+dtr)+lamk'*oscalg(xk+dtr) + alpha*0.5*sum((lamk.*oscalg(xk+dtr)).^2);

    deltaq = -(Glk'*dtr+0.5*dtr'*Bk*dtr);
    oscalL = oscalf(xk)+ lamk'*oscalg(xk) + alpha*0.5*sum((lamk.*oscalg(xk)).^2);
    oscalLd = oscalf(xk+dtr)+lamk'*oscalg(xk+dtr) + alpha*0.5*sum((lamk.*oscalg(xk+dtr)).^2);

    deltaf = oscalL-oscalLd;
    rhok = deltaf/deltaq;
    store_rhok(k) = rhok;

    %根据下降效果，更新信赖域
    if rhok<=eta1 || deltaq<=0
        dta = gma1*dta;
        xk=xk+1*pro_gk;
        lamk=lamk+1*(-lamk+xpro(lamk+gk+diag(lamk)*gk.^2,0,inf));
        cou=cou+1;
        store_dta(k)=dta;
        continue;
    end

    if rhok >= eta1 && rhok <= eta2
        dta = dta;
    end

    if rhok > eta2
        dta=min(gma2*dta,dtamax);
    end
    store_dta(k)=dta;
    xk=xk+dtr;
    lamk=lamk+(-lamk+xpro(lamk+gk+10*diag(lamk)*gk.^2,0,inf));
    k=k+1;
end
    output=[xk;lamk];
end

