function g = oscalg(x)
%% R2-->R2
    x1=x(1); x2=x(2);
    g1=-2*x1^4+8*x1^3-8*x1^2+x2-2;
    g2=-4*x1^4+32*x1^3-88*x1^2+96*x1+x2-36;
    g=[g1, g2]';
end

