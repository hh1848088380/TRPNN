clear;
clc;
close all;
warning off;
global ode_result dim_x dim_l xl xu RNN10_para TRU_para ODE_para epsilon;

ode_result=[];

num_pso=[6];%NN
M=4;%M
Moto=50;%随机次数

dim_x=2;
dim_l=2;

xl= [0,0]'; %约束下限
xu= [3,4]'; %约束上限


RNN10_para.MaxIter=1000;
RNN10_para.h=0.05;
RNN10_para.r=RNN10_para.h/2;
RNN10_para.theta=0.01;%0.01
RNN10_para.alpha=1;%0.2
RNN10_para.pro=2;
RNN10_para.inta=0.002;%0.002

TRU_para.MaxIter=1000;
TRU_para.alpha=10;
TRU_para.dta=0.5;
TRU_para.dtamax=7;
TRU_para.eta1=0.25;
TRU_para.eta2=0.75;
TRU_para.gma1=0.5;
TRU_para.gma2=2;


ODE_para.tspan=[0 100]; %ode时间
ODE_para.sigma1=1;
ODE_para.sigma2=0.1;
ODE_para.alpha=1;
ODE_para.c=1;
ODE_para.epsilon=1e-5;
ODE_para.sigma2sq=2;
ODE_para.sigma2sq=1;
ODE_para.pl=0.05;
ODE_para.paf=1;

% load('trust4_N6M4.mat');
methods= {'RNN5','RNN6','RNN7','RNN8','RNN9','RNN10','RNN11','TRPNN'};

for np=1:length(num_pso)
    NN=num_pso(np);
    rng('shuffle');
    % 生成 dim_x 部分的随机数，范围为 [-3, -8]
    random_x = unifrnd(-5, 5, dim_x, NN, Moto);

    % 生成 dim_l 部分的随机数，范围为 [-1, -5] (根据你需求修改范围)
    random_l = unifrnd(-5, 5, dim_l, NN, Moto);

    % 合并 dim_x 和 dim_l 部分
    init = [random_x; random_l];
    for i=1:Moto
%         disp(['i=',num2str(i),';N=',num2str(NN),';M=',num2str(M)]);
        initt=init(:,:,i);
        for j=1:numel(methods)
            if NN==1
                [f_val, z_val, time, itr] = compare_fun(methods{j}, initt); %z是组合变量
                disp([methods{j},'-i=',num2str(i),';N=',num2str(NN)]);
            else
                [f_val, z_val, time, itr] = CNO_FUN(methods{j}, M, initt,i,NN);
            end
            eval([methods{j} '_x(:,i) = z_val(1:dim_x);']);
            eval([methods{j} '_f(i) = f_val;']);
            eval([methods{j} '_time(i) = time;']);
            if j==1 || j==2
                eval([methods{j} '_itr(i) = itr;']);
            end
        end
    end


end
disp('finish');
