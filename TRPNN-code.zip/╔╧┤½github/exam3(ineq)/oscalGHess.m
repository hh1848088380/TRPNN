function Hs = oscalHessG(x, smstep)
    % oscalHessG 计算每个不等式函数的黑塞矩阵
    %
    % 输入:
    % x - 自变量向量
    % smstep - 微小的步长，用于有限差分法计算
    %
    % 输出:
    % Hs - 包含每个不等式函数黑塞矩阵的cell数组
    
    % 计算g的值以获取不等式函数的数量
    g = oscalg(x);
    num_g = length(g);       % 不等式函数的数量
    x_len = length(x);       % 自变量的维数
    
    % 初始化一个cell数组来存储每个不等式函数的Hessian矩阵
    Hs = cell(num_g, 1);
    
    % 遍历每个不等式函数g1, g2, ..., gn
    for j = 1:num_g
        H = zeros(x_len);    % 初始化当前不等式函数的Hessian矩阵
        for i = 1:x_len
            % 为当前变量进行微小的正负变化
            xp = x; xm = x;
            xp(i) = x(i) + smstep;
            xm(i) = x(i) - smstep;
            
            % 计算梯度差分，基于第j个不等式函数
            gp = oscalg(xp);  % g 在 xp 点的值 (向量)
            gm = oscalg(xm);  % g 在 xm 点的值 (向量)
            
            % 针对第 j 个不等式函数，计算第 i 列的梯度差分
            H(:, i) = (gp(j) - gm(j)) / (2 * smstep);
        end
        
        % 确保 Hessian 矩阵是对称的
        Hs{j} = (H + H') / 2;
    end
end
