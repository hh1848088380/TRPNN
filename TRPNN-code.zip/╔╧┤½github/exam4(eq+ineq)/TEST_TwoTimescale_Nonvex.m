function [x_return, time_consu]=TEST_TwoTimescale_Nonvex()
rng('default');
% testfmincon(2)
% stop()
id = 6;  % 9 is convex problem
[objFunc,c_ceq,lb,ub,x0,h,g,plot_box] = getTestFunctions(id);  % id=2 not OK
%1, 2, 3, 6, 11
% for problem 1   a=[2.000000210334291, 0.105784555984438]  %
% for problem 2   a=1.1166    1.2204    1.5378    1.9728    1.7911
% for problem 3   a=[3.999948003856722, 3.999948003856935]
% for problem 4   a=[3.000000000570960, 2.000000000612590]
% for problem 5   a=[0.822875655915169,0.911437827926484]
%  for problem 6  a=[0.390856, 0.39085576, 0.374, 0.374,15.974,0.00001];
f = objFunc;
x_up = ub';   % x-x_up=-Inf, then s=Inf, problem? since -inf +inf = NaN
x_low = lb';
%x0 = [-5,0];  % for id1 = fourtimescale, also for Xia�� has changed in problem
x0 = x0';
ipt = IPT_TimeScaleForBatchCompare(f,h,g,x_up,x_low,x0);
%[x_return,lastobj,time_consu,auxi_cell] = ipt.mainAugLag(plot_box,1,30000,1.5,2,1.5);
[x_return,lastobj,time_consu,auxi_cell] =ipt.mainAugLag(plot_box,1,200,1,2,1);
return
%id 1 = xxx
%id 12 = 1.5,2,1.5
% above is for figure
% [x_return,lastobj,time_consu,auxi_cell] =ipt.mainEvent(plot_box,1,200,1,2,1);
constraint_violation = get_constraint_violation(x_return,h,g,x_up,x_low);
lastobj
time_consu
constraint_violation
% stop
result_cell = auxi_cell;
filename = ['problem_',num2str(id),'.mat'];
pre = [cd,'\'];
savePath = [pre,filename];
save_flag = 1;
if save_flag ==1
    save(savePath,'result_cell');
    'success'
end
end

% function f=getObj(x,b)
% f = -x(1)^2-x(2)^2;
% end
% 
% function [ceq]=get_ceq(x,a)
% % ceq and c empty TODO
% %ceq = [2*x(1)+x(2),x(1)^2+2*x(2)];
% %ceq = [2*x(1)+x(2),x(1)+2*x(2)];
% %ceq = [sin(x(1)),1-cos(x(2))];
% ceq = [x(1)+x(2)-1];
% %ceq = [];
% end
% 
% function [c]=get_c(x) % lower and upper bounds not considered
% %c = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
% c = [x(1)^2+x(2)^2-5];
% end

function [] = testfmincon(id)
options = optimoptions('fmincon');
%options = optimoptions(options,'MaxFunEvals',200); % 7000, 12000
options = optimoptions(options,'Algorithm','sqp');
[objFunc,c_ceq,lb,ub,x0,h,g] = getTestFunctions(id); 
% objFunc(x0)
% h(x0)
% g(x0)
% stop()
% id=1 the same, 
% id=2   interior point good,
% id=3  initial point sensitive
[x,fval,exitflag,output]  = fmincon(objFunc,x0,[],[],[],[],lb,ub,c_ceq,options);
format long
constraint_violation = get_constraint_violation(x',h,g,ub',lb')
fval
end


