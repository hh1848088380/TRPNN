function [objFunc,c_ceq,lb,ub,x0,h,g,plot_box] = getTestFunctions( id )
if id==1
    objFunc = @(x) getObj_1(x);
    c_ceq = @(x) c_ceq_1(x);
    h = @(x) h_1(x);
    g = @(x) g_1(x);
    %x0 = unifrnd(-10,10,1,2);
    x0 = [-5,0];  % for id1 = fourtimescale, also for Xia�� has changed in problem
    lb = [-1, -1];
    ub = [2, 1];
    plot_box = 1;
elseif id==2
    objFunc = @(x) getObj_2(x);
    c_ceq = @(x) c_ceq_2(x);
    h = @(x) h_2(x);
    g = @(x) g_2(x);
    x0 = [0,0,0,0,0];
    %x0 = unifrnd(-5,5,1,5);
    lb = [-5, -5,-5, -5,-5];
    ub = [5, 5, 5, 5, 5];
    plot_box = 1;
elseif id==3   
    objFunc = @(x) getObj_3hat(x);
    c_ceq = @(x) c_ceq_3hat(x);
    h = @(x) h_3hat(x);
    g = @(x) g_3hat(x);
    rng('shuffle');
    x0 = [1,2];  % good local solution
    %bar_x_0 = [2.1,0.105];
    lb = [-8, 0]; % IPT need this
    ub = [10, 10];
    plot_box = 0;
elseif id==4   
    objFunc = @(x) getObj_4(x);
    c_ceq = @(x) c_ceq_4(x);
    h = @(x) h_4(x);
    g = @(x) g_4(x);
    x0 = [2,6];  % initial point sensitive
    %bar_x_0 = [2.1,0.105];
    lb = [-5, -5];
    ub = [5, 5];
    plot_box = 1;
elseif id==5    %0.8229, 0.9114
    objFunc = @(x) getObj_5(x);
    c_ceq = @(x) c_ceq_5(x);
    h = @(x) h_5(x);
    g = @(x) g_5(x);
    %x0 = [10,-10];  % initial point sensitive
    x0 = unifrnd(-10,10,1,2);
    %bar_x_0 = [2.1,0.105];
    lb = [-100, -100];
    ub = [100, 100];
    plot_box = 0;
elseif id==6    % [0.772,0.517,0.204,0.388,3.036,5.097]
    objFunc = @(x) getObj_6(x);
    c_ceq = @(x) c_ceq_6(x);
    h = @(x) h_6(x);
    g = @(x) g_6(x);
%     rng('shuffle');
    %x0 = [0.5, 0.5 , 0.5 , 0.5 ,0.5, 0.5];  % initial point sensitive
    x0 = unifrnd(0,0.6,1,6);
    %x0 = [1.0 0.393 0.0 0.388 1e-5 15.975];
    %x0 = [0.5, 0.5 , 0.5 , 0.5 ,0.5, 0.5];
    %bar_x_0 = [2.1,0.105];
    %lb = [0,0,0,0,0,0];
    lb = [0,0,0,0,1e-5,1e-5];
    ub = [1,1,1,1,16,16];
    plot_box = 1;
elseif id==7    % [0.772,0.517,0.204,0.388,3.036,5.097]
    objFunc = @(x) getObj_7(x);
    c_ceq = @(x) c_ceq_7(x);
    h = @(x) h_7(x);
    g = @(x) g_7(x);
    %x0 = [0.5, 0.5 , 0.5 , 0.5 ,0.5, 0.5];  % initial point sensitive
    x0 = unifrnd(-5,5,1,6);
    lb = [0,0,0,0,0,0];
    ub = [1e5,1e5,1e5,1e5,1e5,1e5];
    plot_box = 1;
elseif id==8  % Li2015 NN
    objFunc = @(x) getObj_8(x);
    c_ceq = @(x) c_ceq_8(x);
    h = @(x) h_8(x);
    g = @(x) g_8(x);
    %x0 = [0.5,0.125];
    x0 = unifrnd(-5,5,1,2);
    lb = [-10,-10];
    ub = [10,10];
    plot_box = 1;
elseif id==9    %Liu TNN 2008
    objFunc = @(x) getObj_9(x);
    c_ceq = @(x) c_ceq_9(x);
    h = @(x) h_9(x);
    g = @(x) g_9(x);
    x0 = unifrnd(-5,5,1,4);
    %x0 = zeros([1,4]);
    lb = [-2,-2,-10,-10];
    ub = [2,2,10,10];
    plot_box = 1;
elseif id==10    %Liu TNN 2008
    objFunc = @(x) getObj_10(x);
    c_ceq = @(x) c_ceq_10(x);
    h = @(x) h_10(x);
    g = @(x) g_10(x);
    x0 = unifrnd(-5,5,1,4);
    %x0 = zeros([1,4]);
    lb = [-2,-2,-10,-10];
    ub = [2,2,10,10];
    plot_box = 1;
elseif id==11    %Liu TNN 2008
    objFunc = @(x) getObj_11(x);
    c_ceq = @(x) c_ceq_11(x);
    h = @(x) h_11(x);
    g = @(x) g_11(x);
    %x0 = unifrnd(-5,5,1,4);
    x0 = zeros([1,3]);
    lb = [0,0,0];
    ub = [6,4,10];
    plot_box = 1;
elseif id==12    %Liu TNN 2008
    n = 100; % �����������Ӧ��һ�� ע���޸�  60
    objFunc = @(x) getObj_12(x,n);
    c_ceq = @(x) c_ceq_12(x,n);
    h = @(x) h_12(x,n);
    g = @(x) g_12(x,n);
    %x0 = unifrnd(-5,5,1,4);
    %x0 = zeros([1,3]);
    %x0 = 0.1*ones([1,n]);
    %x0 = unifrnd(-0.5,0.5,1,n);  % n=200 good also  may use this converge
    %to zero
    %x0 = unifrnd(-1.5,1,1,n);
    %x0 = unifrnd(-0.5,0.5,1,n); % original
    x0 = unifrnd(0.5,2.5,1,n);
    %x0 = unifrnd(-0.1,0.1,1,n);
    lb = 0*ones([1,n]);
    ub = 2.5*ones([1,n]);
    plot_box = 1;
elseif id==13    %Liu TNN 2008
    objFunc = @(x) getObj_13(x);
    c_ceq = @(x) c_ceq_13(x);
    h = @(x) h_13(x);
    g = @(x) g_13(x);
    rng('shuffle');
    x0 = unifrnd(-15,15,1,2);
    %x0 = zeros([1,4]);
    lb = [0,0];
    ub = [3,4];
    plot_box = 1;
elseif id==14
    objFunc = @(x) getObj_14(x);
    c_ceq = @(x) c_ceq_14(x);
    h = @(x) h_14(x);
    g = @(x) g_14(x);
    rng('shuffle');
    x0 = unifrnd(-5,5,1,2);
    %x0 = zeros([1,4]);
    lb = [2,2];
    ub = [6,6];
    plot_box = 1;
end

%  a biconvex, that book 1999, HVAC control, or vehicle control?
end


function [c,ceq] = c_ceq_1(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = g_1(x);
ceq = h_1(x);
end

function [ceq] = h_1(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
ceq = [];
end

function [c] = g_1(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [];
end

function f=getObj_1(x)
f = cos(x(1))*sin(x(2))-x(1)/(1+x(2)^2);
end

function [c,ceq] = c_ceq_2(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = g_2(x);
ceq = h_2(x);
end

function [ceq] = h_2(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
ceq = [x(1)+x(2)^2+x(3)^3-3*sqrt(2)-2,x(2)-x(3)^2+x(4)-2*sqrt(2)+2,x(1)*x(5)-2];
end

function [c] = g_2(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [];
end

function f=getObj_2(x)
x1 = x(1);
x2 = x(2);
x3 = x(3);
x4 = x(4);
x5 = x(5);
f = (x1-1)^2+(x1-x2)^2+(x2-x3)^3+(x3-x4)^4+(x4-x5)^4;
end




function [c,ceq] = c_ceq_3(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = g_3(x);
ceq = h_3(x);
end

function [c] = g_3(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [];
end

function [ceq] = h_3(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
ceq = [];
end

function f=getObj_3(x)
y = x(2);
x = x(1); % dangerous
f1_1 = (x-4)^2+(y-4)^2+0.1;
f1 = -1.0/f1_1;

f2_1 = (x-1)^2+(y-1)^2+0.2;
f2 = -1.0/f2_1;

f3_1 = (x-8)^2+(y-8)^2+0.2;
f3 = -1.0/f3_1;
f = f1+f2+f3;
end


function [c,ceq] = c_ceq_3hat(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = g_3hat(x);
ceq = h_3hat(x);
end

function [c] = g_3hat(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [-x(1)+x(2)-8,x(2)-x(1)^2-2*x(1)+2];
end

function [ceq] = h_3hat(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
ceq = [];
end

function f=getObj_3hat(x)
f = x(1)^4-14*x(1)^2+24*x(1)-x(2)^2;
end

%%
function [c,ceq] = c_ceq_4(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_4(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_4(x);
end

function f=getObj_4(x)
f=0;
end

function [ceq] = h_4(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
x1 = x(1);
x2 = x(2);
ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
end

function [c] = g_4(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [];
end


%%
function [c,ceq] = c_ceq_5(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_5(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_5(x);
end

function f=getObj_5(x)
f=(x(1))^2+(0.5*x(2))^2;
end

function [ceq] = h_5(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
ceq = [x(1)+x(2)];
end

function [c] = g_5(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [x(1)^2+x(2)^2-1];
end

%%
function [c,ceq] = c_ceq_6(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_6(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_6(x);
end

function f=getObj_6(x)
f=-x(4); %
end

function [ceq] = h_6(x)
k1 = 0.09755988;
%k2 = 0.09658428;
k2 = 0.99*k1;
k3 = 0.0391908;
k4 = 0.9*k3;
ceq1 = x(1)+k1*x(1)*x(5)-1;
ceq2 = x(2)-x(1)+k2*x(2)*x(6);
ceq3 = x(3)+x(1)+k3*x(3)*x(5)-1;
ceq4 = x(4)-x(3)+x(2)-x(1)+k4*x(4)*x(6);
ceq = [ceq1,ceq2,ceq3,ceq4];
end

function [c] = g_6(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c1 = x(5)^(0.5)+x(6)^(0.5)-4;
c = [c1];
end




%%
function [c,ceq] = c_ceq_7(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_7(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_7(x);
end

function f=getObj_7(x)
f=-x(1)-x(2); %
end

function [ceq] = h_7(x)
ceq1 = 5.0/12*x(1)-x(2)+x(3)-35.0/12;
ceq2 = x(5)-x(1)+5;
ceq3 = 5.0/2*x(1)+x(2)+x(4)-35.0/2;
ceq4 = x(2)+x(6)-5;
ceq = [ceq1,ceq2,ceq3,ceq4];
end

function [c] = g_7(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [];
end


%%
function [c,ceq] = c_ceq_8(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_8(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_8(x);
end

function f=getObj_8(x)
f=2-x(1)*x(2); %
end

function [ceq] = h_8(x)
ceq = [];
end

function [c] = g_8(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [x(1)+4*x(2)-1,x(1)^2+x(2)^2-1];
end


%%
function [c,ceq] = c_ceq_9(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_9(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_9(x);
end

function f=getObj_9(x)
f=(x(1)-1)^4+(x(2)+x(3))^6 + (x(4)+2)^4+exp(x(1)+x(2)+x(3)+x(4)); %
end

function [ceq] = h_9(x)
c1 = 2.*x(1)-3.*x(2)+1.0*x(3)-1;
c2 = 1.0*x(2)+2.0*x(3)-1.0*x(4)+3;
%A = [2.,-3.,1.,0.;0.,1.,2.,-1.];
%b = [1.0;-3.0];
%ceq = (A*x-b)';
ceq = [c1,c2];
end

function [c] = g_9(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [];
end


%%
function [c,ceq] = c_ceq_10(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_10(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_10(x);
end

function f=getObj_10(x)
f=x(1)^2+x(2)^2 +x(4)^2+ x(3)^2; %
end

function [ceq] = h_10(x)
ceq = [];
end

function [c] = g_10(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [norm(x)^2-2];
end

%%
function [c,ceq] = c_ceq_11(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_11(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_11(x);
end

function f=getObj_11(x)
f=-x(1)-x(2); %
end

function [ceq] = h_11(x)
c1 = x(3)^2-x(1)^2-x(2)^2-8;
ceq = [c1];
end

function [c] = g_11(x)
c = [x(1)+x(2)-x(3)];
end



%%
function [c,ceq] = c_ceq_12(x,n)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_12(x,n);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_12(x,n);
end

function f=getObj_12(x,n)
s1 = sqrt(sum(x.^2)/n);
s2 = sum(cos(2*pi*x))/n;
f=-20.0*exp(-0.2*s1)-exp(s2)+20+exp(1); %
end

function [ceq] = h_12(x,n)
%ceq = [c1];
ceq = [];
end

function [c] = g_12(x,n)
%c = [x(1)+x(2)-x(3)];
%c1 = sum(x.^3)-15;
%c1 = sum(x.^3);
%c = [c1];
c = [];
end

function [c,ceq] = c_ceq_13(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_13(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_13(x);
end

function f=getObj_13(x)
f=-x(1)-x(2); %
end

function [ceq] = h_13(x)
ceq = [];
end

function [c] = g_13(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [-2*x(1)^4+8*x(1)^3-8*x(1)^2+x(2)-2, -4*x(1)^4+32*x(1)^3-88*x(1)^2+96*x(1)+x(2)-36]; 
end


function [c,ceq] = c_ceq_14(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c =g_14(x);
%ceq = [4*x1^3+4*x1*x2+2*x2^2-42*x1-14, 4*x2^3+2*x1^2+4*x1*x2-26*x2-22];
ceq = h_14(x);
end

function f=getObj_14(x)
f=-1/10*x(1)^2+1/60*x(2)^3-1/5*x(1)-4*x(2); %
end

function [ceq] = h_14(x)
ceq = [];
end

function [c] = g_14(x)
%c  = [x(1)^2+x(2)^2,2*x(1)^2+8*x(2)^2];
c = [2*x(1)+9*x(2)-48, 5*x(1)+3*x(2)-35]; 
end

