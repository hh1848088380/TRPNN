function f = oscalf(x)
    x4=x(4);
    f=-x4;
end

