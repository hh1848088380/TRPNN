function [output,k] = RNN11(z0)
global RNN10_para xl xu dim_x dim_l dim_m;
xk=z0(1:dim_x);
lamk=z0(dim_x+1:dim_x+dim_l);
muk=z0(dim_x+dim_l+1:dim_x+dim_l+dim_m);

MaxIter=RNN10_para.MaxIter;
h=RNN10_para.h;
r=RNN10_para.r;
theta=0;
alpha=RNN10_para.alpha;
beta=RNN10_para.beta;
pro=RNN10_para.pro;
inta=RNN10_para.inta;

%参数设置
smstep=1e-6;
k=1;
s(k)=h;
sumd=0;

store_x(:,k)=xk;
store_lam(:,k)=lamk;
store_mu(:,k)=muk;

fk=oscalf(xk);  store_fk(k)=fk;
gk=oscalg(xk);  store_gk(:,k)=gk;
hk=oscalh(xk);  store_hk(:,k)=hk;

Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;
Ggk=oscalGg(xk,smstep);  store_Ggk(:,:,k)=Ggk;
Ghk=oscalGh(xk,smstep);  store_Ghk(:,:,k)=Ghk;

for i=1:length(gk)
    gGgk(:,i)=lamk(i)^2*gk(i)*Ggk(:,i);%一阶梯度
end

for i=1:length(hk)
    gGhk(:,i)=muk(i)^2*hk(i)*Ghk(:,i);%一阶梯度
end

Glk=Gfk+Ggk*lamk+Ghk*muk+alpha*sum(gGgk,2)+beta*sum(gGhk,2); store_Glk(:,k)=Glk;

pro_gk=-xk+xpro(xk-Glk,xl,xu);
store_pro_gk(:,k)=pro_gk;

pro_lamk=-lamk+xpro(lamk+gk+1*diag(lamk)*gk.^2,0,inf);
store_pro_lamk(:,k)=pro_lamk;

pro_muk=hk+1*diag(muk)*hk.^2;
store_pro_muk(:,k)=pro_muk;
while(k<MaxIter)
    %计算Euler函数值和梯度

    xk=xk+h*pro_gk;
    lamk=lamk+h*pro_lamk;
    muk=muk+h*pro_muk;
    k=k+1;

    store_x(:,k)=xk;
    store_lam(:,k)=lamk;
    store_mu(:,k)=muk;

    fk=oscalf(xk);  store_fk(k)=fk;
    gk=oscalg(xk);  store_gk(:,k)=gk;
    hk=oscalh(xk);  store_hk(:,k)=hk;

    Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;
    Ggk=oscalGg(xk,smstep);  store_Ggk(:,:,k)=Ggk;
    Ghk=oscalGh(xk,smstep);  store_Ghk(:,:,k)=Ghk;

    for i=1:length(gk)
        gGgk(:,i)=lamk(i)^2*gk(i)*Ggk(:,i);%一阶梯度
    end

    for i=1:length(hk)
        gGhk(:,i)=muk(i)^2*hk(i)*Ghk(:,i);%一阶梯度
    end

    Glk=Gfk+Ggk*lamk+Ghk*muk+alpha*sum(gGgk,2)+beta*sum(gGhk,2);
    pro_gk=-xk+xpro(xk-Glk,xl,xu);
    store_pro_gk(:,k)=pro_gk;

    pro_lamk=-lamk+xpro(lamk+gk+alpha*diag(lamk)*gk.^2,0,inf);
    store_pro_lamk(:,k)=pro_lamk;

    pro_muk=hk+beta*diag(muk)*hk.^2;
    store_pro_muk(:,k)=pro_muk;


    hx=xk+0.5*s(k-1)*(store_pro_gk(:,k-1) + pro_gk);
    hlamk=lamk+0.5*s(k-1)*(store_pro_lamk(:,k-1) + pro_lamk);
    hmuk=muk+0.5*s(k-1)*(store_pro_muk(:,k-1)+pro_muk);




    delta=norm([hx;hlamk;hmuk]-[xk;lamk;muk]);

    sumd=sumd+delta;

    s(k)= ( r/(pro*delta+inta*sumd) )^(theta/2)*s(k-1);

    %判断终止条件 (norm(pro_gk)<err && norm(lamk'*gk)<1e-6 && norm(hk)<1e-6)
    if norm([xk;lamk;muk]-[store_x(:,k-1);store_lam(:,k-1);store_mu(:,k-1)])<1e-5
        break;
    end

end
    output=[xk;lamk;muk];
end







