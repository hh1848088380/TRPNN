function g = oscalg(x)
%% R2-->R2
    x1=x(1); x2=x(2);
    g1=2*x1+9*x2-48;
    g2=5*x1+3*x2-35;
    g=[g1, g2]';
end

