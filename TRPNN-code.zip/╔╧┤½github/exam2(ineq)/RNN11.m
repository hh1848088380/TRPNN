function [output,k] = RNN11(z0)
global RNN10_para xl xu dim_x dim_l;
xk=z0(1:dim_x);
lamk=z0(dim_x+1:dim_x+dim_l);

MaxIter=RNN10_para.MaxIter;
h=RNN10_para.h;
r=RNN10_para.r;
theta=0;
alpha=RNN10_para.alpha;
pro=RNN10_para.pro;
inta=RNN10_para.inta;

%参数设置
smstep=1e-6;
k=1;
s(k)=h;
sumd=0;

store_x(:,k)=xk;
store_lam(:,k)=lamk;

fk=oscalf(xk);  store_fk(k)=fk;
gk=oscalg(xk);  store_gk(:,k)=gk;

Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;
Ggk=oscalGg(xk,smstep);  store_Ggk(:,:,k)=Ggk;

for i=1:length(gk)
    gGgk(:,i)=lamk(i)^2*gk(i)*Ggk(:,i);%一阶梯度
end

Glk=Gfk+Ggk*lamk+alpha*sum(gGgk,2);
pro_gk=-xk+xpro(xk-Glk,xl,xu);
store_pro_gk(:,k)=pro_gk;

pro_lamk=-lamk+xpro(lamk+gk,0,inf);
store_pro_lamk(:,k)=pro_lamk;
while(k<MaxIter)
    %计算Euler函数值和梯度

    xk=xk+h*pro_gk;
    lamk=lamk+h*(-lamk+pro_lamk);
    k=k+1;


    store_x(:,k)=xk;
    store_lam(:,k)=lamk;

    fk=oscalf(xk);  store_fk(k)=fk;
    gk=oscalg(xk);  store_gk(:,k)=gk;

    Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;
    Ggk=oscalGg(xk,smstep);  store_Ggk(:,:,k)=Ggk;

    for i=1:length(gk)
        gGgk(:,i)=lamk(i)^2*gk(i)*Ggk(:,i);%一阶梯度
    end

    Glk=Gfk+Ggk*lamk+alpha*sum(gGgk,2);

    pro_gk=-xk+xpro(xk-Glk,xl,xu);
    store_pro_gk(:,k)=pro_gk;

    pro_lamk=-lamk+xpro(lamk+gk,0,inf);
    store_pro_lamk(:,k)=pro_lamk;

    hx=xk+0.5*s(k-1)*(store_pro_gk(:,k-1) + pro_gk);
    hlamk=lamk+0.5*s(k-1)*(store_pro_lamk(:,k-1) + pro_lamk);


    delta=norm([hx;hlamk]-[xk;lamk]);

    sumd=sumd+delta;

    s(k)= ( r/(pro*delta+inta*sumd) )^(theta/2)*s(k-1);

    %判断终止条件 (norm(pro_gk)<err && norm(lamk'*gk)<1e-6 && norm(hk)<1e-6)
    if norm(Glk)<1e-10
        break;
    end

end
    output=[xk;lamk];
end





