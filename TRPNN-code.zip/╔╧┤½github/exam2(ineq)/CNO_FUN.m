function [CNO_f,CNO_x,CNO_toltime,CNO_itr] = CNO_FUN(method, M, init, echo, nump)
    global dim_x dim_l;
    
    m=0; %记录找到相同best的次数
    T=1; %记录迭代次数
    Tmax=14;
    [D,N]=size(init);
    c0=0.8; c1=2; c2=2; %PSO parameters
    v=2*rand(D,N);
    vmax=5;
    vmin=-5;
    xmax=5;
    xmin=-5;
    %% 初始化个体最优位置和最优值
    p=init;
    pbest = ones(N,1)*inf;

    %% 初始化全局最优位置和最优值
    g = ones(D,1);
    gi = ones(D,1);
    gbest = inf;
    gibest=inf;

    for i = 1:N
        if pbest(i) < gbest
            g = p(:,i);
            gbest = pbest(i);
        end
    end
    gb=inf;
    
    while m<M
        for i = 1:N
            [tem_f(i), x(:,i), time, itr] = compare_fun(method, init(:,i));


            tem_lam(:,i)=x(dim_x+1:dim_x+dim_l,i);
            tem_g(:,i) = oscalg(x(1:dim_x,i));
            tem_gfeas(i)=norm(xpro(tem_g(:,i),0,inf),inf);

            tem_itr(i)=itr;
            tem_toltime(i)=time;

            if strcmp(method, 'RNN5')
                tem_fL(i)=tem_f(i)+sum(xpro(tem_g(:,i),0,inf));
            else
                tem_fL(i)=tem_f(i)+tem_lam(:,i)'*tem_g(:,i);
            end

            if tem_gfeas(i)<1e-6 && tem_fL(i)<pbest(i) %%不满足约束条件的不算
                p(:,i) = x(:,i);
                pbest(i) = tem_fL(i);

                if pbest(i) < gbest
                    g = p(:,i);
                    gbest = pbest(i);
                end
            else
                p(:,i) = x(:,i);
                pbest(i) = tem_fL(i);
                if pbest(i) < gibest
                    gi = p(:,i);
                    gibest= pbest(i);
                end
            end
            
            
            v(:,i) = c0*v(:,i) + c1*rand*(p(:,i)-x(:,i)) + c2*rand*(g-x(:,i));
            init(:,i) = init(:,i) + v(:,i);
            

            %%边界处理
            for j = 1:D
                if v(j,i)>vmax || v(j,i)<vmin
                    v(j,i) = rand*(vmax-vmin)+vmin;
                end
                if init(j,i)>xmax || init(j,i)<xmin
                    init(j,i) = rand*(xmax-xmin)+xmin;
                end
            end

        end

        gb(T)= gbest; %最优值

        if T>=2 && gb(T)==inf && gb(T-1)==inf
            mi=mi+1;
            batch_x(:,T)=gi; %失败的最优个体
        else
            mi=0;
        end


         if T>=2 && gb(T)-gb(T-1)<1e-4
             m=m+1;
             mi=0;
             batch_x(:,T)=g; %最优个体
         else
             m=0;
         end
         T=T+1;
         disp([method,'-T=',num2str(T),';i=',num2str(echo),';N=',num2str(nump)]);
         
         batch_itr(T)=sum(tem_itr); %迭代次数 
         batch_time(T)=sum(tem_toltime); %耗时

         if T>Tmax || mi>4 
             break;
         end

    end
    CNO_x=batch_x(:,end);
    CNO_f=oscalf(CNO_x(1:dim_x));
    CNO_itr=sum(batch_itr);
    CNO_toltime=sum(batch_time);
%     CNO_T=T;
end