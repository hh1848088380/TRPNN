function dot_all = RNN5_9(t,z,method)
global xl xu ODE_para dim_x dim_l;

sigma1 = ODE_para.sigma1;
sigma2 = ODE_para.sigma2;
sigma1sq = ODE_para.sigma2sq;
sigma2sq = ODE_para.sigma2sq;
arg_para = ODE_para.arg_para;
alpha = ODE_para.alpha;
c = ODE_para.c;
pl = ODE_para.pl;

x=z(1:dim_x);

if ~strcmp(method, 'RNN5')
    lamb=z(dim_x+1:dim_x+dim_l);
end


smstep=1e-6;

g=oscalg(x);
graf=oscalGf(x,smstep);
grag=oscalGg(x,smstep);

switch method
    case 'RNN6'
        dotx= (1/arg_para)*(-x+xpro(x-graf-grag*lamb-alpha*grag*diag(lamb.^2)*g,xl,xu));
%         dotlamb= (1/arg_para)*(-lamb + xpro(lamb+g+alpha*diag(lamb)*g.^2,0,inf));
        dotlamb= (1/arg_para)*(-lamb + xpro(lamb+g+alpha*diag(lamb)*g.^2,0,inf));
        dot_all=[dotx; dotlamb];
    case 'RNN8'
        dotx = (1/sigma1)*(-x+xpro(x-graf-grag*lamb,xl,xu)) ;
        dotlamb= (1/sigma2)*(-lamb + xpro(lamb+g,0,inf)) ;
        dot_all=[dotx; dotlamb];
    case 'RNN9'
        zx=z(dim_x+dim_l+1:end);
        grafz=oscalGf(zx,smstep);
        grafzx=grafz+c*(zx-x);
        dotx = (1/sigma1)*(zx-x);
        dotzx = (1/sigma2)*(-zx+xpro(zx-grafzx-grag*lamb,xl,xu));
        dotlamb= (1/sigma2)*(-lamb + xpro(lamb + grag'*(zx-x) + g,0,inf) );
        dot_all=[dotx; dotlamb;dotzx];
    case 'RNN7'
        y=z(dim_x+dim_l+1:end);
        Q=oscalHess(x,smstep);
        dotx = (1/sigma1sq)*y;
        doty = (1/sigma2sq)*(-y + xpro( y-y-graf - grag*lamb ,xl,xu));
        dotlamb = (1/sigma2sq)*(-lamb + xpro(lamb + grag'*y + g ,0,inf));
         
        dot_all=[dotx;  dotlamb; doty];
    case 'RNN5'
        one_grag=one_oscalGg(x,smstep);
        one_g=one_oscalg(x);
        delta_g=zeros(size(one_grag));
        indices = find(one_g >= 0);
        delta_g(:,indices) = one_grag(:,indices);
        dotx=-graf-(1/pl)*sum(delta_g,2);
        dot_all=dotx;
end

t;
end