function grad = oscalGg(x,smstep)
    x_len=length(x); %%变量个数
%     g_len=length(g); %%不等式个数
%     grad=zeros(x_len,g_len);
%     for j=1:g_len
        for i=1:x_len
            xp=x; xm=x;
            xp(i)=x(i)+smstep;
            xm(i)=x(i)-smstep;
            grad(:,i)=(oscalg(xp)-oscalg(xm))/(2*smstep);
        end
%     end
    grad=grad';
end

