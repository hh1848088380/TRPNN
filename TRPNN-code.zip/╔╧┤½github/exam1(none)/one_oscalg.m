function g = one_oscalg(x)
%% R2-->R2
    x1=x(1); x2=x(2);
    g1=-1-x1;
    g2=x1-2;
    g3=-1-x2;
    g4=x2-1;
    g=[g1, g2, g3, g4]';
end

