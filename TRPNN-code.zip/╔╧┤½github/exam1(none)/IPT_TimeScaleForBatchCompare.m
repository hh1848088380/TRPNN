classdef IPT_TimeScaleForBatchCompare
    % trajectory generation learning consider noise or no noise
    % solution uniqeness, that RNN method assume unique?
    properties
        n;e_n;
        x_up;x_low;
        x0;f;h;gOri;
        tao;zeta;Delta0;epsilon_tol;epsilon_mu0;rho;
        eta;theta;nu0;mu0;
        n_ineq;n_eq;
        e; % vector with all one elements
        g0; % row vector, initial inequality vector
        df;dh;dg;
        sb_x;dg_boxconst;n_ineq_ori;
        ind_up;ind_low;
    end
    methods
        function obj = IPT_TimeScaleForBatchCompare(f,h,g,x_up,x_low,x0)
            %warning off
            war = warning('query','MATLAB:nearlySingularMatrix');
            war_id = war.identifier;
            warning('off',war_id)
            %%%%%%%%%%%%%%%%%%%%%%%%%
            obj.x0 = x0;
            [input_m,input_n] =size(x_up);
            if input_m==1
                obj.n = input_n;
            else
                obj.n = input_m;
            end
            obj.e_n = ones(obj.n,1);
            obj.x_up=x_up;obj.x_low=x_low;
            [obj.ind_up,obj.ind_low] = obj.getEffeBox();
            obj.f = f; obj.h = h; obj.gOri = g;
            
            obj.rho = 0.3;
            obj.tao = 0.995;
            obj.zeta = 0.8;
            obj.Delta0 = 1;
            obj.epsilon_tol = 1e-7;%1e-8;
            obj.epsilon_mu0 = 0.1;
            obj.eta = 1e-8;
            obj.theta=0.2;
            obj.nu0 = 1;
            obj.mu0 = 0.1;
            
            c=obj.gOri(obj.x0);
            ceq=obj.h(obj.x0);
            obj.n_ineq_ori = size(c,2); % no box constraint
            obj.n_ineq = size(c,2)+length(obj.ind_up)+length(obj.ind_low); % g dont have box constraints, so add 2*obj.n fro box constr
            obj.n_eq = size(ceq,2);
            
            obj.e = ones([obj.n_ineq,1]);
            
            obj.g0 = obj.g(obj.x0); % row vector
            
            [obj.df,obj.dh,obj.dg,obj.sb_x] = obj.getJacobian();
            
            eye_n = eye(obj.n);
            obj.dg_boxconst = [eye_n(:,obj.ind_up),-eye_n(:,obj.ind_low)];
        end
        
        function [effect_index_up,effect_index_low] = getEffeBox(obj)
            effect_index_up = [];
            effect_index_low = [];
            for i =1:obj.n
                if obj.x_up(i)~=Inf
                    effect_index_up=[effect_index_up i];%box_cons = [box_cons, x(i)-obj.x_up(i)];
                end
                if obj.x_low(i)~=-Inf
                    effect_index_low=[effect_index_low i];%box_cons = [box_cons, -x(i)+obj.x_low(i)];
                end
            end
        end
        
        function y=get_df(obj,x)
            y = obj.df(x);
            %y = eval(subs(obj.df,obj.sb_x,x));
        end
        
        function y=get_dh(obj,x)
            y = obj.dh(x);
            %y = double(subs(obj.dh,obj.sb_x,x));
        end
        
        function y=get_dg(obj,x)
            %y = double(subs(obj.dg,obj.sb_x,x));
            y = obj.dg(x);
            y = [y obj.dg_boxconst];
        end
        
        function y=g(obj,x) % real g
            y = [obj.gOri(x),(x(obj.ind_up)-obj.x_up(obj.ind_up))',(-x(obj.ind_low)+obj.x_low(obj.ind_low))'];
        end
        
        function [df,dh,dg,sb_x]=getJacobian(obj)
            sb_x = sym('x',[obj.n,1]);
            %%%%%%%%%%%% f
            f_to = obj.f(sb_x);
            df=jacobian(f_to,sb_x)';
            df = simplify(df);
            df = matlabFunction(df,'vars', {sb_x});
            %df = matlabFunction(df,'vars', {sb_x},'File','myfile');
            %%%%%%%%%%%%% h
            h_to = obj.h(sb_x);
            dh=jacobian(h_to,sb_x)';
            dh = simplify(dh);
            dh = matlabFunction(dh,'vars', {sb_x});
            %%%%%%%%%%%%g
            g_to = obj.gOri(sb_x);
            dg=jacobian(g_to,sb_x)';
            dg = simplify(dg);
            dg = matlabFunction(dg,'vars', {sb_x});
        end
        
        function main(obj,plot_box)
            % solve this problem: min f(x) s.t. h(x)=0; g(x) <=0; 
            %(bound included in g(x))
            mu = obj.mu0+1e-10; % initize mu
            %mu = 5; % initize mu
            %nu = obj.nu0; % initize nu
            Delta = obj.Delta0;
            %epsilon_mu = obj.epsilon_mu0;
            s = max([-1.5*obj.g0; ones([1,obj.n_ineq])])'; 
            %from setting is from python, it colud redece the steps
            %s = ones([1,obj.n_ineq])'; % from python

            %[y,z] = obj.getInitial_yz(obj.x0,s,mu);
            % struct('maxNewtownIter', 100,'maxtotalIter',100,'c1',0.01,'c2',0.3,...
            %                 'epsilon',1e-4,'taw',0.995,'Final_toler',1e-6);
            Hess_L = 1*eye(obj.n);
            
            options = odeset();
            t_b =1200;
            tspan = linspace(0,t_b,200);
            t_cons_x =0.1; % 0.1
            t_cons_mu = 1;
            t_cons_d = 1; % current useless
            t_cons_d_H = 50; % 50 for id =1,4 OK
            
            %ini_state = zeros(2*var_num+size(A,1),1);
            ini_state = [mu;obj.x0;s;Hess_L(:)];
            Delta = Inf; % trust region Inf important, original need change
            [t,x]=ode45(@obj.rightHandReal,tspan,ini_state,options,Delta,t_cons_x,t_cons_d,t_cons_mu,t_cons_d_H);
            time_const = 1;
            %%%%%%%%%%%%
            t_expand= kron(ones(1,1+obj.n+obj.n_ineq+obj.n^2),t*time_const);
            figure(1)
            plot(t_expand, x)
            %%%%%%%%%%%%
            if plot_box==1
                plot_n = obj.n+obj.n_ineq;
                t_expand= kron(ones(1,plot_n),t*time_const);
                plot_state = x(:,2:1+plot_n);
            else
                plot_n = obj.n+obj.n_ineq-2*obj.n; % x,s   -  box_s
                t_expand= kron(ones(1,plot_n),t*time_const);
                plot_state = x(:,2:1+plot_n);
            end
            figure(1)
            plot(t_expand, plot_state)  % (x,s) -  box_s
            xlabel('Time')
            % figure(2)
            % plot(t_expand(1:end-1,:), d)
            last_x = x(end,1:end)';
            last_x(1)
            last_x(2:obj.n+1)
%             last_x(1:5)
%             last_x(6:end)
        end
        
        function [dx] = rightHandReal(obj,t,x,Delta,t_cons_x,t_cons_d,t_cons_mu,t_cons_d_H)
            mu = x(1);
            state_n_xs = obj.n+obj.n_ineq;
            state_real = x(2:state_n_xs+1);
            Hess_L_vec = x(state_n_xs+2:state_n_xs+obj.n^2+1);
            x_real = state_real(1:obj.n);
            s_real = state_real(obj.n+1:obj.n+obj.n_ineq);
            [real_dx,real_ds,Hess_L_right] = obj.innerSQPRight(x_real,s_real,Delta,mu,Hess_L_vec);
%             if mu>0
%                 du = -1e-4;%du = -1e-2 % u = 0.1*exp(-t)+1e-8;  important for decreasing
%             else
%                 du = 0;
%             end
            du = -0.01*mu;%-0.5*mu;
            add1 = 1.0/t_cons_x*[real_dx;real_ds];%Hess_L_right];
            dx = [1.0/t_cons_mu*du;add1;1.0/t_cons_d_H*Hess_L_right];
        end
        
        function [t_expand,plot_state,t_obj,obj_list,last]=mainNoLog(obj,plot_box)
            Hess_L = 1*eye(obj.n);
            options = odeset();
            t_b =1500; % 30 for id 1,3, 60 for id 3,   1000 for id last
            tspan = linspace(0,t_b,500);
            t_cons_x =2; % 0.1
            t_cons_y = 0.01; % current useless
            t_cons_H =200;% 50 for id 6; 200 for other
            
            %ini_state = zeros(2*var_num+size(A,1),1);
            ini_state = [obj.x0; zeros(obj.n,1); zeros(obj.n_ineq_ori,1);zeros(obj.n_eq,1); Hess_L(:)];
            [t,x]=ode45(@obj.rightHandNoLog,tspan,ini_state,options,t_cons_x,t_cons_y,t_cons_H);
            
            time_const = 1e-6; 
            % id 2,3,4 = 1e-4
            % id 6 1e-5, 
            %%%%%%%%%%%%
%             t_expand= kron(ones(1,2*obj.n+obj.n_ineq_ori+obj.n_eq+obj.n^2),t*time_const);
%             figure(1)
%             plot(t_expand, x)
%             stop()
            %%%%%%%%%%%% for states
            %plot_n = 2*obj.n+obj.n_ineq_ori+obj.n_eq;
            plot_n = 2*obj.n;
            if plot_box==1
                %plot_n = 2*obj.n;
                t_expand= kron(ones(1,plot_n),t*time_const);
                plot_state = x(:,1:plot_n);
            else
                %plot_n = 2*obj.n; % x,s   -  box_s
                t_expand= kron(ones(1,plot_n),t*time_const);
                plot_state = x(:,1:plot_n);
            end
            figure(1)
            plot(t_expand, plot_state)  % (x,s) -  box_s
            xlabel('Time')
            %%%%%% for obj values
            obj_list = [];
            for i=1:size(x,1)
                obj_list = [obj_list;obj.f(x(i,1:obj.n)')];
            end
            figure(2)
            t_obj = t*time_const;
            plot(t_obj, obj_list)
            xlabel('Time')
            
            last_x = x(end,1:end)';
            last = last_x(1:obj.n)
        end
        
        function [dx] = rightHandNoLog(obj,t,x,t_cons_x,t_cons_y,t_cons_d_H)
            real_x = x(1:obj.n);
            real_y = x(obj.n+1:2*obj.n);
            real_u = x(2*obj.n+1:2*obj.n+obj.n_ineq_ori);
            real_v = x(2*obj.n+obj.n_ineq_ori+1:2*obj.n+obj.n_ineq_ori+obj.n_eq);
            Hess_L_vec = x(2*obj.n+obj.n_ineq_ori+obj.n_eq+1:2*obj.n+obj.n_ineq_ori+obj.n_eq+obj.n^2);
            
            dfx = obj.df(real_x);
            dhx = obj.dh(real_x);
            dgx = obj.dg(real_x);
            %%%
            x_right = real_y;
            %%%
            Hess_L = reshape(Hess_L_vec,obj.n,obj.n);
            lx = obj.x_low-real_x;
            bx = obj.x_up-real_x;
            if ~isempty(real_u) && ~isempty(real_v)
                P_Y_x_inside = Hess_L*real_y+dfx+dgx*real_u-dhx*real_v;
                u_right = -real_u+max(real_u+dgx'*real_y+obj.gOri(real_x)',0);
                v_right = -(dhx'*real_y+obj.h(real_x)');
            elseif ~isempty(real_u)
                P_Y_x_inside = Hess_L*real_y+dfx+dgx*real_u;
                u_right = -real_u+max(real_u+dgx'*real_y+obj.gOri(real_x)',0);
                v_right = [];
            elseif ~isempty(real_v)
                P_Y_x_inside = Hess_L*real_y+dfx-dhx*real_v;
                u_right = [];
                v_right = -(dhx'*real_y+obj.h(real_x)');
            else
                P_Y_x_inside = Hess_L*real_y+dfx;
                u_right = [];
                v_right = [];
            end
            y_right = -real_y+reinforce_box_boundaries(real_y-P_Y_x_inside, lx, bx);
            
            x_right = 1.0/t_cons_x*x_right;
            delta_t = 1e-3;
            % why only change following fast? 1/10 1/50?  TODO
            %Lag_update = obj.get_dLagNoLog(real_x+x_right*delta_t,real_u,-real_v)-obj.get_dLagNoLog(real_x,real_u,-real_v); %obj.forwardDiff(d_lag,x_old);
            Lag_update = obj.get_dLagNoLog(real_x+x_right*delta_t,real_u,-real_v)-obj.get_dLagNoLog(real_x,real_u,-real_v);
            %Lag_update = obj.get_dLagNoLog(real_x+x_right,real_u,real_v)-obj.get_dLagNoLog(real_x,real_u,real_v);
            %Hess_L_right = BFGS_Damped_right(x_right,Lag_update,Hess_L);
            Hess_L_right = BFGS_Damped_right(x_right*delta_t,Lag_update,Hess_L);
            %Hess_L_right = BFGS_Damped_right(x_right,Lag_update,Hess_L);
            %Hess_L_right = 1.0/t_cons_d_H*Hess_L_right(:);
            %Hess_L_right = 1.0/10*Hess_L_right(:);
            %Hess_L_right = 1.0/2.5*Hess_L_right(:); % for id 6
            Hess_L_right = 1.0/t_cons_d_H*Hess_L_right(:);
            %x_right = 1.0/t_cons_x*x_right;
            y_right = 1.0/t_cons_y*y_right;
            u_right = 1.0/t_cons_y*u_right;
            v_right = 1.0/t_cons_y*v_right;
            dx = [x_right;y_right;u_right;v_right;Hess_L_right];
        end
        
        function [Hess]=computeAugLag(obj,penal_alpha) % u for inequality, v for equality
            if obj.n_ineq_ori==0
                isEmptyU = 1;
            else
                isEmptyU = 0;
            end
            if obj.n_eq==0
                isEmptyV = 1;
            else
                isEmptyV = 0;
            end
            sb_u = sym('u',[obj.n_ineq_ori,1]);
            sb_v = sym('v',[obj.n_eq,1]);
            fx = obj.f(obj.sb_x);
            gx = obj.gOri(obj.sb_x);
            hx = obj.h(obj.sb_x);
            % lag negative problem hx????? TODO
            if isEmptyU && isEmptyV
                Lag = fx;
                Aug_Lag = Lag;
                Hess = hessian(Lag,obj.sb_x);
            elseif isEmptyU
                Lag = fx+hx*sb_v;
                Aug_Lag = Lag+penal_alpha/2*(hx*hx');
                Hess = hessian(Lag,obj.sb_x);
            elseif isEmptyV
                Lag = fx+gx*sb_u;
                Aug_Lag = Lag+penal_alpha/2*(gx*diag(sb_u)*gx');
                Hess = hessian(Lag,obj.sb_x);
            else
                Lag = fx+gx*sb_u+hx*sb_v;
                Aug_Lag = Lag+penal_alpha/2*(hx*hx'+gx*diag(sb_u)*gx');
                Hess = hessian(Lag,obj.sb_x);
%                 Hess = simplify(Hess);
%                 Hess= matlabFunction(Hess,'vars', {obj.sb_x,sb_u,sb_v});
            end
            Hess = simplify(Hess);
            Hess= matlabFunction(Hess,'vars', {obj.sb_x,sb_u,sb_v});
        end
        
        function [last,lastobj,time_consu,auxi_cell] = mainAugLag(obj,plot_box,plot_flag,t_b,H_amp,t_cons_x,t_cons_y) % constant Q now
            Hess_L = H_amp*eye(obj.n); %H_amp=0.1 for all ids except 6, Hess_L = 0.01*eye(obj.n) for id 6 !!!!!
            options = odeset();
            %t_b =60; % % 30 for id 1,3, 60 for id 3,   1000 for id last !!!!
            tspan = linspace(0,t_b,1000);
            %t_cons_x =2.0; % 0.1
%             t_cons_x =2.0;
%             t_cons_y = 0.01; % current useless
            %t_cons_y = 2.0; % current useless
            %Hess=obj.computeAugLag(penal_alpha);  % for aug, but bad
            %ini_state = zeros(2*var_num+size(A,1),1);
            %ini_state = [2.702;10.702; zeros(obj.n,1); zeros(obj.n_ineq_ori,1);zeros(obj.n_eq,1)];

%             ini_state = [obj.x0; zeros(obj.n,1); zeros(obj.n_ineq_ori,1);zeros(obj.n_eq,1)]; %%原本选择的ini_state
            ini_state = obj.x0;
            t1=clock;
            [t,x]=ode45(@obj.rightHandAugLag,tspan,ini_state,options,t_cons_x,t_cons_y,Hess_L);
            t2=clock;
            time_consu = etime(t2,t1);
            time_const = 1e-6; 
            plot_n = 2*obj.n+obj.n_ineq_ori+obj.n_eq;
            %plot_n = 2*obj.n;
            if plot_box==1
                %plot_n = 2*obj.n;
                t_expand= kron(ones(1,plot_n),t*time_const);
                %plot_state = x(:,1:plot_n);
                plot_state = x(:,1:plot_n);
            else
                %plot_n = 2*obj.n; % x,s   -  box_s
                t_expand= kron(ones(1,plot_n),t*time_const);
                %plot_state = x(:,1:plot_n);
                plot_state = x(:,1:plot_n);
            end
            if plot_flag
%                 figure(1)
%                 plot(t_expand, plot_state)  % (x,s) -  box_s
%                 xlabel('Time')
            end
            %%%%%% for obj values
            obj_list = [];
            for i=1:size(x,1)
                obj_list = [obj_list;obj.f(x(i,1:obj.n)')];
            end
            t_obj = t*time_const;
            if plot_flag
%                 figure(2)
%                 plot(t_obj, obj_list)
%                 xlabel('Time')
            end
            last_x = x(end,1:end)';
            last_u = last_x(2*obj.n+1:2*obj.n+obj.n_ineq_ori+obj.n_eq);
            last = [last_x(1:obj.n);last_u];
            lastobj = obj.f(last(1:obj.n));
            %last_x(2*obj.n+1:end)
            
            auxi_cell = {};
            auxi_cell{1} = t_expand;
            auxi_cell{2} = plot_state;
            auxi_cell{3} = t_obj;
            auxi_cell{4} = obj_list;
        end
        
        function [dx] = rightHandAugLag(obj,t,x,t_cons_x,t_cons_y,Hess_L)
            real_x = x(1:obj.n);
            real_y = x(obj.n+1:2*obj.n);
            real_u = x(2*obj.n+1:2*obj.n+obj.n_ineq_ori);
            real_v = x(2*obj.n+obj.n_ineq_ori+1:2*obj.n+obj.n_ineq_ori+obj.n_eq);
            %Hess_L_vec = x(2*obj.n+obj.n_ineq_ori+obj.n_eq+1:2*obj.n+obj.n_ineq_ori+obj.n_eq+obj.n^2);
            
            dfx = obj.df(real_x);
            dhx = obj.dh(real_x);
            dgx = obj.dg(real_x);
            %%%
            x_right = real_y;
            %%%
            %Hess_L = Hess(real_x,real_u,-real_v);
            %Hess_L = Hess_L+Hess_L1;
            lx = obj.x_low-real_x;
            bx = obj.x_up-real_x;
            if ~isempty(real_u) && ~isempty(real_v)
                P_Y_x_inside = Hess_L*real_y+dfx+dgx*real_u-dhx*real_v;
                u_right = -real_u+max(real_u+dgx'*real_y+obj.gOri(real_x)',0);
                v_right = -(dhx'*real_y+obj.h(real_x)');
            elseif ~isempty(real_u)
                P_Y_x_inside = Hess_L*real_y+dfx+dgx*real_u;
                u_right = -real_u+max(real_u+dgx'*real_y+obj.gOri(real_x)',0);
                v_right = [];
            elseif ~isempty(real_v)
                P_Y_x_inside = Hess_L*real_y+dfx-dhx*real_v;
                u_right = [];
                v_right = -(dhx'*real_y+obj.h(real_x)');
            else
                P_Y_x_inside = Hess_L*real_y+dfx;
                u_right = [];
                v_right = [];
            end
            y_right = -real_y+reinforce_box_boundaries(real_y-P_Y_x_inside, lx, bx);
            
            x_right = 1.0/t_cons_x*x_right;
            %x_right = 1.0/t_cons_x*x_right;
            y_right = 1.0/t_cons_y*y_right;
            u_right = 1.0/t_cons_y*u_right;
            v_right = 1.0/t_cons_y*v_right;
            dx = [x_right;y_right;u_right;v_right];
            
        end
        
        function [last,lastobj,time_consu,auxi_cell] = mainEvent(obj,plot_box,plot_flag,t_b,H_amp,t_cons_x,t_cons_y) % constant Q now
            Hess_L = H_amp*eye(obj.n); %H_amp=0.1 for all ids except 6, Hess_L = 0.01*eye(obj.n) for id 6 !!!!!
            %t_b =60; % % 30 for id 1,3, 60 for id 3,   1000 for id last !!!!
            samNum = 500;
            tspan = linspace(0,t_b,samNum);
            ini_state = [obj.x0; zeros(obj.n,1); zeros(obj.n_ineq_ori,1);zeros(obj.n_eq,1)];
            options=odeset();
            t1=clock;
            [t,x]=ode45(@obj.rightHandEvent,tspan,ini_state,options,t_cons_x,t_cons_y,Hess_L);
            t2=clock;
            time_consu = etime(t2,t1);
            criteria = 1e-5;
            [return_x,return_time] = obj.detectStop(samNum,t,x,criteria,time_consu);
            time_const = 1e-6;
            %plot_n = 2*obj.n+obj.n_ineq_ori+obj.n_eq;
            plot_n = 2*obj.n;
            if plot_box==1
                %plot_n = 2*obj.n;
                t_expand= kron(ones(1,plot_n),t*time_const);
                plot_state = x(:,1:plot_n);
            else
                %plot_n = 2*obj.n; % x,s   -  box_s
                t_expand= kron(ones(1,plot_n),t*time_const);
                plot_state = x(:,1:plot_n);
            end
            if plot_flag
                figure(1)
                plot(t_expand, plot_state)  % (x,s) -  box_s
                xlabel('Time')
            end
            %%%%%% for obj values
            obj_list = [];
            for i=1:size(x,1)
                obj_list = [obj_list;obj.f(x(i,1:obj.n)')];
            end
            t_obj = t*time_const;
            if plot_flag
                figure(2)
                plot(t_obj, obj_list)
                xlabel('Time')
            end
            last_x = x(end,1:end)';
            
            last = last_x(1:obj.n);
            lastobj = obj.f(last);
%             last = return_x(1:obj.n)';
%             lastobj = obj.f(last);
%             time_consu = return_time;
            
            auxi_cell = {};
            auxi_cell{1} = t_expand;
            auxi_cell{2} = plot_state;
            auxi_cell{3} = t_obj;
            auxi_cell{4} = obj_list;
        end
        
        function [return_x,return_time] = detectStop(obj,samNum,t,x,criteria,time)
            first_i = samNum;
            first_detect = 1;
            dx_list = [];
            best_norm = Inf;
            best_i = samNum;
            for i=1:samNum
                if i>1
                    dx = (x(i,:)-x(i-1,:))/(t(i)-t(i-1));
                    norm_dx = norm(dx)/max(size(dx));
                    dx_list = [dx_list,norm_dx];
                    if norm_dx<criteria && first_detect==1
                        first_i = i;
                        first_detect=0
                    end
                    if norm_dx<best_norm
                        best_norm = norm_dx;
                        best_i = i;
                    end
                end
            end
            return_time = time*first_i/samNum;
            return_x = x(best_i,:);
        end
        
        function [dx] = rightHandEvent(obj,t,x,t_cons_x,t_cons_y,Hess_L)
            real_x = x(1:obj.n);
            real_y = x(obj.n+1:2*obj.n);
            real_u = x(2*obj.n+1:2*obj.n+obj.n_ineq_ori);
            real_v = x(2*obj.n+obj.n_ineq_ori+1:2*obj.n+obj.n_ineq_ori+obj.n_eq);
            %Hess_L_vec = x(2*obj.n+obj.n_ineq_ori+obj.n_eq+1:2*obj.n+obj.n_ineq_ori+obj.n_eq+obj.n^2);
            
            dfx = obj.df(real_x);
            dhx = obj.dh(real_x);
            dgx = obj.dg(real_x);
            %%%
            x_right = real_y;
            %%%
            %Hess_L = Hess(real_x,real_u,-real_v);
            %Hess_L = Hess_L+Hess_L1;
            lx = obj.x_low-real_x;
            bx = obj.x_up-real_x;
            if ~isempty(real_u) && ~isempty(real_v)
                P_Y_x_inside = Hess_L*real_y+dfx+dgx*real_u-dhx*real_v;
                u_right = -real_u+max(real_u+dgx'*real_y+obj.gOri(real_x)',0);
                v_right = -(dhx'*real_y+obj.h(real_x)');
            elseif ~isempty(real_u)
                P_Y_x_inside = Hess_L*real_y+dfx+dgx*real_u;
                u_right = -real_u+max(real_u+dgx'*real_y+obj.gOri(real_x)',0);
                v_right = [];
            elseif ~isempty(real_v)
                P_Y_x_inside = Hess_L*real_y+dfx-dhx*real_v;
                u_right = [];
                v_right = -(dhx'*real_y+obj.h(real_x)');
            else
                P_Y_x_inside = Hess_L*real_y+dfx;
                u_right = [];
                v_right = [];
            end
            y_right = -real_y+reinforce_box_boundaries(real_y-P_Y_x_inside, lx, bx);
            
            x_right = 1.0/t_cons_x*x_right;
            %x_right = 1.0/t_cons_x*x_right;
            y_right = 1.0/t_cons_y*y_right;
            u_right = 1.0/t_cons_y*u_right;
            v_right = 1.0/t_cons_y*v_right;
            dx = [x_right;y_right;u_right;v_right];
        end
        
        
        function [y,z] = getInitial_yz(obj,x,s,mu)
            A = obj.getA_hat(x,s);
            [y,z] = obj.get_multiplers(A,x,mu);
        end
        
        function [dx,ds,Hess_L_right] = innerSQPRight(obj,x,s,Delta,mu,Hess_L_vec)
            Hess_L = reshape(Hess_L_vec,obj.n,obj.n);
            A = obj.getA_hat(x,s);
            [y,z] = obj.get_multiplers(A,x,mu); %the same as previous inversion implementations 
            [vx,tild_vs,obj_m] = obj.getVertical(x,s,Delta,A);
            vs = diag(s)*tild_vs;
            [wx,tild_ws,obj_q] = obj.getTangential(x,s,z,Delta,A,Hess_L,mu,vx,tild_vs);
            ws = diag(s)*tild_ws;
            dx = vx+wx;
            ds = vs+ws;
            
            x_update = dx;
            %d_lag = @ (x) obj.getLagBarrPorb(x,s,y,z,mu);
            Lag_update = obj.get_dLag(x+dx,y,z)-obj.get_dLag(x,y,z); %obj.forwardDiff(d_lag,x_old);
            Hess_L_right = BFGS_Damped_right(x_update,Lag_update,Hess_L);
            Hess_L_right = Hess_L_right(:);
        end
        
        function [x,s,y,z,Delta,Hess_L,total_ite] = innerSQP(obj,x,s,Delta,mu,nu,epsilon_mu,Hess_L,total_ite)
            A = obj.getA_hat(x,s);
            [y,z] = obj.get_multiplers(A,x,mu); %the same as previous inversion implementations 
            inner_id = 1;
            E_x = obj.get_E(x,s,mu,y,z); % mu=0
            E_x_0 = obj.get_E(x,s,0,y,z); % mu=0
            while(E_x>epsilon_mu && ...
                    E_x_0>obj.epsilon_tol &&...
                    Delta>1e-8 && inner_id <200)
                x_old = x;  % BFGS
                [vx,tild_vs,obj_m] = obj.getVertical(x,s,Delta,A);
                vs = diag(s)*tild_vs;
                [wx,tild_ws,obj_q] = obj.getTangential(x,s,z,Delta,A,Hess_L,mu,vx,tild_vs);
                ws = diag(s)*tild_ws;
                dx = vx+wx;
                ds = vs+ws;
                vpred = obj.getVpred(x,s,A,[vx;tild_vs]);
                nu = obj.updateNu(nu,obj_m,obj_q,vpred); % update nu
                pred = -obj_q+nu*vpred;
                ared = obj.getMerit(x,s,nu,mu)-obj.getMerit(x+dx,s+ds,nu,mu);
                if ared >= obj.eta*pred
                    x = x+dx; s = s+ds;
                    gamma = ared/pred;
                    Delta = obj.updateDelta([dx;ds],Delta,gamma,obj.eta);
                else
                    v_tild = [vx;tild_vs]; w_tild =[wx;tild_ws];
                    [yx,ys] = obj.SOC(x,dx,s,ds,A,v_tild,w_tild);
                    corr_ared = obj.getMerit(x,s,nu,mu)-obj.getMerit(x+dx+yx,s+ds+ys,nu,mu);
                    if norm([yx;ys]) ~=0 && corr_ared >= obj.eta*pred && all(s+ds+ys >=(1-obj.tao)*s)
                        x = x+dx+yx; s = s+ds+ys;
                        %Delta = Delta; % no change of Delta
                    else
                        % x no change
                        Delta = 0.5*Delta;  % [0.1,0.5]
                    end
                end
                A = obj.getA_hat(x,s);
                [y,z] = obj.get_multiplers(A,x,mu);
                E_x = obj.get_E(x,s,mu,y,z); % mu=0
                E_x_0 = obj.get_E(x,s,0,y,z);
                % s_k = x(k+1)-x(k)
                % y_k = df(k+1)- df(k)
                x_update = x-x_old;
                %d_lag = @ (x) obj.getLagBarrPorb(x,s,y,z,mu);
                Lag_update = obj.get_dLag(x,y,z)-obj.get_dLag(x_old,y,z); %obj.forwardDiff(d_lag,x_old);
                Hess_L = BFGS_Damped(x_update,Lag_update,Hess_L);
                inner_id = inner_id+1;
                total_ite = total_ite+1;
            end
        end
        
%         function y=getRNNTwoTimeScale(obj)
%             var_num = 2;
%             t_b = 1e-4;
%             ini_state = ones(var_num,1);
%             nn = NonConvexNN(var_num);
%             cal_df = @(x) df(x);
%             cal_g_dg = @(x) g_dg(x);
%             nn.compute(ini_state,cal_df,cal_g_dg,t_b)
%         end
        
        function [vx,tild_vs,obj_m]=getVertical_RNN(obj,x,s,Delta,A)
            %     """Approximately  minimize ``1/2*|| A x + b ||^2`` inside trust-region.
            %     1/2*|| A x + b ||^2 = 0.5x'A'Ax+b'Ax+0.5*b'b
            %     Approximately solve the problem of minimizing ``1/2*|| A x + b ||^2``
            %     subject to ``||x|| < Delta`` and ``lb <= x <= ub`` using a modification
            %     Delta = trust_radius, I noted
            %     of the classical dogleg approach.
            in_A = A';
            in_b = [( obj.h(x) )';( obj.g(x) )'+s];
            trust_radius = obj.zeta*Delta; % input radius
            Q = in_A'*in_A; c=in_A'*in_b;
            %obj.n_ineq
            lb_s = -obj.tao/2*obj.e;
            cal_g_dg = @(x) obj.getg_dg_VerticalRNN(x, trust_radius,lb_s);
            cal_df = @(x) obj.df_VerticalRNN(x,Q,c);
            %bar_d = [bar_dx;bar_ds]  %obj.n_ineq+obj.n
            var_num = obj.n_ineq+obj.n;
            t_b = 1e-4;
            ini_state = zeros(var_num,1);
            nn = NonConvexNN(var_num);
            tild_v = nn.compute(ini_state,cal_df,cal_g_dg,t_b);
            vx = tild_v(1:obj.n);
            tild_vs = tild_v(obj.n+1:end);
            %%% compute obj
            obj_m = 2* in_b'*A'*tild_v+tild_v'*(A*A')*tild_v;
        end
        
        function [g,d_g]=getg_dg_VerticalRNN(obj,x, trust_radius,lb_s)
            % g<= 0 containing  ``||x|| < trust_radius`` and ``lb <= x <= ub``
            g1 = lb_s-x(obj.n+1:end);
            d_g1 = [zeros(obj.n,obj.n_ineq);-eye(obj.n_ineq)];
            g2 = x'*x-trust_radius^2;
            d_g2 = 2*x;
            g = [g1;g2];
            d_g = [d_g1,d_g2];
        end
        
        function d_y=df_VerticalRNN(obj,x,Q,c)
            %1/2*|| A x + b ||^2 = 0.5x'A'Ax+b'Ax+0.5*b'b
            %Q = A_in'*A_in, c=A_in'*b_in
            d_y = Q*x+c;
        end

        function [wx,tild_ws,obj_q] = getTangential_RNN(obj,x,s,z,Delta,A,Hess_L,mu,vx,tild_vs)
            %Solve equality-constrained quadratic programming problem
            %``min 1/2 x.T H x + x.t c``  subject to ``A x + b = 0`` and,
            %     possibly, to trust region constraints ``||x|| < trust_radius``
            %     and box constraints ``lb <= x <= ub``.
            tild_v = [vx;tild_vs];
            df_x = obj.get_df(x);   %obj.forwardDiff(obj.f,x);
            S = diag(s);
            Sigma = obj.get_Sigma(z,s,mu);
            G = blkdiag(Hess_L,S*Sigma*S);
            c = [df_x;-mu*obj.e]+G*tild_v;
            in_A = A';
            in_b = zeros([obj.n_eq+obj.n_ineq,1]);
            trust_radius = sqrt(Delta^2-norm(tild_v)^2);
            lb_s = -obj.tao*obj.e-tild_vs;
%             lb = [-Inf*ones([obj.n,1]);-obj.tao*obj.e-tild_vs];
%             ub = Inf*ones([obj.n_ineq+obj.n,1]);
%             allvecs = projected_cg(H, c, in_A, in_b, trust_radius, lb, ub);
            cal_g_dg = @(x) obj.getg_dg_TangentialRNN(x, trust_radius,lb_s,in_A,in_b);
            cal_df = @(x) obj.df_TangentialRNN(x,G,c);
            var_num = obj.n_ineq+obj.n;
            t_b = 1e-8;
            ini_statexx = zeros(var_num,1);
            %ini_statexx = obj.ini_state;
            nn = NonConvexNN(var_num);
            tild_w = nn.compute(ini_statexx,cal_df,cal_g_dg,t_b);
            
            wx = tild_w(1:obj.n);
            tild_ws = tild_w(obj.n+1:end);
            
            % compute obj
            add = tild_w+tild_v;
            obj_q = [df_x;-mu*obj.e]'*add+0.5*add'*G*add;
        end
        
        function [g,d_g]=getg_dg_TangentialRNN(obj,x, trust_radius,lb_s,A,b)
            % g<= 0 containing  ``||x|| < trust_radius`` and ``lb_s <= x_s ``
            % Ax+b=0
            g1 = lb_s-x(obj.n+1:end);
            d_g1 = [zeros(obj.n,obj.n_ineq);-eye(obj.n_ineq)];
            g2 = x'*x-trust_radius^2;
            d_g2 = 2*x;
            g3 = A*x+b;
            d_g3 = A';
            g4 = -A*x-b;
            d_g4 = -A';
            g = [g1;g2;g3;g4];
            d_g = [d_g1,d_g2,d_g3,d_g4];
        end
        
        function d_y=df_TangentialRNN(obj,x,Q,c)
            %0.5x'Qx+c'x
            d_y = Q*x+c;
        end

        function [yx,ys] = SOC(obj,x,dx,s,ds,A,v_tild,w_tild)
            y = zeros([obj.n+obj.n_ineq,1]);
            if norm(v_tild) <=0.1* norm(w_tild)
                y = A*((A'*A)\[obj.h(x+dx)';obj.g(x+dx)'+s+ds] );
            end
            yx = y(1:obj.n);
            ys = y(obj.n+1:end);
        end
        
        function new_Delta = updateDelta(obj,d,Delta,gamma,eta)
            new_Delta = Delta;
            if gamma >= 0.9
                new_Delta = max(7*norm(d),Delta);
                return;
            end
            if gamma >= 0.3
                new_Delta = max(2*norm(d),Delta);
                return;
            end
            
            if gamma >= eta
                new_Delta = Delta;
                return;
            end
            % gamma not able to smaller than eta
        end
        
        function vpred = getVpred(obj,x,s,A,v_tild)
            v1 = [obj.h(x)';obj.g(x)'+s];
            v2 = v1+A'*v_tild;
            vpred = norm(v1)-norm(v2);
            vpred = max(1e-16, vpred); % newly added  TODO, from python
        end
        
        function nu = updateNu(obj,nu_old,m,q,vpred)
            if m==0
                nu = nu_old;
            else
                nu = max(nu_old,q/((1-obj.rho)*vpred));
            end
        end
        
        function [vx,tild_vs,obj_m] = getVertical(obj,x,s,Delta,A)
            in_A = A';
            in_b = [( obj.h(x) )';( obj.g(x) )'+s];
            trust_radius = obj.zeta*Delta;
            lb = [-Inf*ones([obj.n,1]);-obj.tao/2*obj.e];
            ub = Inf*ones([obj.n_ineq+obj.n,1]);
            tild_v = modified_dogleg(in_A, in_b, trust_radius, lb, ub);
            vx = tild_v(1:obj.n);
            tild_vs = tild_v(obj.n+1:end);
            %%% compute obj
            obj_m = 2* in_b'*A'*tild_v+tild_v'*(A*A')*tild_v;
        end
        
        function [wx,tild_ws,obj_q] = getTangential(obj,x,s,z,Delta,A,Hess_L,mu,vx,tild_vs)
            tild_v = [vx;tild_vs];
            df_x = obj.get_df(x);   %obj.forwardDiff(obj.f,x);
            S = diag(s);
            Sigma = obj.get_Sigma(z,s,mu); % z is not used, z is used
            G = blkdiag(Hess_L,S*Sigma*S);
            c = [df_x;-mu*obj.e]+G*tild_v;
            H = G;
            in_A = A';
            in_b = zeros([obj.n_eq+obj.n_ineq,1]);
            trust_radius = sqrt(Delta^2-norm(tild_v)^2);
            lb = [-Inf*ones([obj.n,1]);-obj.tao*obj.e-tild_vs];
            ub = Inf*ones([obj.n_ineq+obj.n,1]);
            allvecs = projected_cg(H, c, in_A, in_b, trust_radius, lb, ub);
            tild_w = allvecs{1};% no solution problem, TODO
            wx = tild_w(1:obj.n);
            tild_ws = tild_w(obj.n+1:end);
            
            % compute obj
            add = tild_w+tild_v;
            obj_q = [df_x;-mu*obj.e]'*add+0.5*add'*G*add;
        end

        function [y,z] = get_multiplers(obj,A,x,mu)
            % iteration k as input
            df_x = obj.get_df(x);%obj.forwardDiff(obj.f,x);
            r = [-df_x;mu*obj.e];%3.12  lag multiplier
            % inv(A'A)A'b2
            [A_row,A_col]=size(A);
            A_ext = [eye(A_row), A;
                A',zeros([A_col,A_col])];
            zero_dim = A_row+A_col-size(r,1);
            zero_vec = zeros([zero_dim,1]);
            b_ext = [r;zero_vec];
            fac = A_ext\b_ext;
            lam = fac(end-(A_col-1):end,1);
            y = lam(1:obj.n_eq);
            z = lam(obj.n_eq+1:end);
        end
        
        function Sigma = get_Sigma(obj,z,s,mu)
            y = zeros([1,obj.n_ineq]);
            for i =1:obj.n_ineq
                if z(i)>0
                    y(i) = z(i)/s(i);
                else
                    y(i) = mu/s(i)^2;
                end
                %y(i) = mu/s(i)^2;
            end
            Sigma = diag(y);
        end
        
        function A = getA_hat(obj,x,s)
            % iteration k as input
            d_g = obj.get_dg(x); %obj.forwardDiff_multi(obj.g,x);
            d_h = obj.get_dh(x); %obj.forwardDiff_multi(obj.h,x);
            A  = [d_h, d_g;
                zeros([obj.n_ineq,obj.n_eq]),diag(s)];
        end
        
        function [E]=get_E(obj,x,s,mu,y,z)
            d_f = obj.get_df(x);%obj.forwardDiff(obj.f,x);
            d_g = obj.get_dg(x);%obj.forwardDiff_multi(obj.g,x);
            d_h = obj.get_dh(x); %obj.forwardDiff_multi(obj.h,x);
            e1 = norm(d_f+d_h*y+d_g*z,Inf);
            e2 = norm(diag(s)*z-mu*obj.e,Inf);
            e3 = norm(obj.h(x),Inf);  % h is row vectro 
            e4 = norm(obj.g(x)'+s,Inf); % g is row vectro, s is column
            E = max([e1,e2,e3,e4]);
        end
        
        function Lag=getLagBarrPorb(obj,x,s,y,z,mu)
            % all are row vectors
            fx = obj.f(x);
            g_x = obj.g(x);
            h_x = obj.h(x);
            Lag = fx-mu*sum(log(s))+ y'*h_x'+z'*(g_x'+s);
        end
        
        function dLag=get_dLag(obj,x,y,z)
            % all are row vectors
            df_x = obj.get_df(x);
            dh_x = obj.get_dh(x);
            dg_x = obj.get_dg(x);
            dLag = df_x+ dh_x*y+dg_x*z;
        end
        
        function dLag=get_dLagNoLog(obj,x,u,v)
            % all are row vectors
            df_x = obj.get_df(x);
            dh_x = obj.get_dh(x);
            dg_x = obj.dg(x);
            dLag = df_x+ dh_x*v+dg_x*u;
        end
        
        function psi=getMerit(obj,x,s,nu,mu)
            % all are row vectors
            f_x = obj.f(x);
            h_x = obj.h(x);
            g_x = obj.g(x);
            inter = [h_x';(g_x'+s)];
            psi = f_x-mu*sum(log(s))+ nu*norm(inter,2);
        end
    end
end
function R=getR(A)
if issparse(A), R = qr(A); else R = triu(qr(A)); end
end

function y=clip(x,xmin,xmax)
[row,col]=size(x);
y=x;
for i =1:row
    if x(i)>xmax
        y(i) = xmax;
    elseif x(i)<xmin
        y(i) = xmin;
    else
        y(i) = x(i);
    end
end
end


function B_next=BFGS(s,y,B)
if (s'*B*s) ~=0 && (y'*s)~=0
    update1 = B*(s*s')*B/(s'*B*s);
    update2 = (y*y')/(y'*s);
    B_next = B-update1+update2;
else
    B_next = B;
end
end

% function B_next=BFGS(s,y,B)
% if (s'*B*s) ~=0
%     update1 = B*(s*s')*B/(s'*B*s);
% else
%     update1 = B*(s*s')*B/1e-15;
%     %update1 = 0;
% end
% if y'*s~=0
%     update2 = (y*y')/(y'*s);
% else
%     update2 = (y*y')/1e-15;
%     %update2 = 0;
% end
% B_next = B-update1+update2;
% end

function B_next=BFGS_Damped(s,y,B)
% s_k = x(k+1)-x(k)
% y_k = df(k+1)- df(k)
p1 = s'*y;
p2 = s'*B*s;
judge = p1-0.2*p2;
if judge >=0
    theta = 1;
else
    theta = 0.8*p2/(p2-p1);
end
r = theta*y+(1-theta)*B*s;
B_next = BFGS(s,r,B);
end

function B_right=BFGS_Damped_right(s,y,B)
% s_k = x(k+1)-x(k)
% y_k = df(k+1)- df(k)
p1 = s'*y;
p2 = s'*B*s;
judge = p1-0.2*p2;
if judge >=0
    theta = 1;
else
    theta = 0.8*p2/(p2-p1);
end
r = theta*y+(1-theta)*B*s;
B_right = BFGS_right(s,r,B);
end


function B_right=BFGS_right(s,y,B)
if (s'*B*s) ==0 
    update1 = B*(s*s')*B/1e-15;
else
    update1 = B*(s*s')*B/(s'*B*s);
end

if (y'*s)==0
    update2 = (y*y')/1e-15;
else
    update2 = (y*y')/(y'*s);
end
B_right = -update1+update2;
end

% function B_right=BFGS_right(s,y,B)
% if (s'*B*s) ~=0 && (y'*s)~=0
%     update1 = B*(s*s')*B/(s'*B*s);
%     update2 = (y*y')/(y'*s);
%     B_right = -update1+update2;
% else
%     [row,col]=size(y*y');
%     B_right = zeros(row,col);
% end
% end

function y=sign_prime(x)
% only 1 and -1
y=sign(x);%1 0 -1
b= (y==0);
y(b)=1;
end

%%%%%%%%%%%%%%%%from python
%function sphere_intersections(z, d, trust_radius,entire_line=False)
function [ta, tb, intersect] = sphere_intersections(z, d, trust_radius,entire_line)
%     Find the intersection between segment (or line) and spherical constraints.
% 
%     Find the intersection between the segment (or line) defined by the
%     parametric  equation ``x(t) = z + t*d`` and the ball
%     ``||x|| <= trust_radius``.
% 
%     Parameters
%     ----------
%     z : array_like, shape (n,)
%         Initial point.
%     d : array_like, shape (n,)
%         Direction.
%     trust_radius : float
%         Ball radius.
%     entire_line : bool, optional
%         When ``True`` the function returns the intersection between the line
%         ``x(t) = z + t*d`` (``t`` can assume any value) and the ball
%         ``||x|| <= trust_radius``. When ``False`` returns the intersection
%         between the segment ``x(t) = z + t*d``, ``0 <= t <= 1``, and the ball.
% 
%     Returns
%     -------
%     ta, tb : float
%         The line/segment ``x(t) = z + t*d`` is inside the ball for
%         for ``ta <= t <= tb``.
%     intersect : bool
%         When ``True`` there is a intersection between the line/segment
%         and the sphere. On the other hand, when ``False``, there is no
%         intersection.
%   
    % Special case when d=0
    if norm(d) == 0
        ta=0; tb=0; intersect=false;
        return;
    end
    % Check for inf trust_radius
    if trust_radius==Inf
        if entire_line
            ta = -Inf;
            tb = Inf;
        else
            ta = 0;
            tb = 1;
        end
        intersect = true;
        return;
    end
%     a = np.dot(d, d);
%     b = 2 * np.dot(z, d);
%     c = np.dot(z, z) - trust_radius^2;
    a = d'*d;
    b = 2 * z'*d;
    c = z'*z - trust_radius^2;
    discriminant = b*b - 4*a*c;
    if discriminant < 0
        intersect = false;
        ta = 0;
        tb = 0;
        return;
    end
    sqrt_discriminant = sqrt(discriminant);
%     # The following calculation is mathematically
%     # equivalent to:
%     # ta = (-b - sqrt_discriminant) / (2*a)
%     # tb = (-b + sqrt_discriminant) / (2*a)
%     # but produce smaller round off errors.
%     # Look at Matrix Computation p.97
%     # for a better justification.
    sign_b = sign(b);
    if sign_b==0
        sign_b=1;
    end
    %aux = b + copysign(sqrt_discriminant, b);
    aux = b + sign_b*abs(sqrt_discriminant);
    ta = -aux / (2*a);
    tb = -2*c / aux;
    time_lit = sort([ta, tb]); % small to big
    ta = time_lit(1); 
    tb = time_lit(2); 
    if entire_line
        intersect = true;
    else
%         # Checks to see if intersection happens
%         # within vectors length.
        if (tb < 0 || ta > 1)
            intersect = false;
            ta = 0;
            tb = 0;
        else
            intersect = true;
%             # Restrict intersection interval
%             # between 0 and 1.
            ta = max(0, ta);
            tb = min(1, tb);
        end
    end
end

%function []=box_intersections(z, d, lb, ub,entire_line=False)
function [ta, tb, intersect]=box_intersections(z, d, lb, ub,entire_line)
% all column vector inputs
%     """Find the intersection between segment (or line) and box constraints.
% 
%     Find the intersection between the segment (or line) defined by the
%     parametric  equation ``x(t) = z + t*d`` and the rectangular box
%     ``lb <= x <= ub``.
% 
%     Parameters
%     ----------
%     z : array_like, shape (n,)
%         Initial point.
%     d : array_like, shape (n,)
%         Direction.
%     lb : array_like, shape (n,)
%         Lower bounds to each one of the components of ``x``. Used
%         to delimit the rectangular box.
%     ub : array_like, shape (n, )
%         Upper bounds to each one of the components of ``x``. Used
%         to delimit the rectangular box.
%     entire_line : bool, optional
%         When ``True`` the function returns the intersection between the line
%         ``x(t) = z + t*d`` (``t`` can assume any value) and the rectangular
%         box. When ``False`` returns the intersection between the segment
%         ``x(t) = z + t*d``, ``0 <= t <= 1``, and the rectangular box.
% 
%     Returns
%     -------
%     ta, tb : float
%         The line/segment ``x(t) = z + t*d`` is inside the box for
%         for ``ta <= t <= tb``.
%     intersect : bool
%         When ``True`` there is a intersection between the line (or segment)
%         and the rectangular box. On the other hand, when ``False``, there is no
%         intersection.
%     """
%     # Make sure it is a numpy array
%     z = np.asarray(z);
%     d = np.asarray(d);
%     lb = np.asarray(lb);
%     ub = np.asarray(ub);
%     # Special case when d=0
    if norm(d) == 0
        ta=0; tb=0; intersect=false;
        return;
    end
%     # Get values for which d==0
    zero_d = (d == 0);
%     # If the boundaries are not satisfied for some coordinate
%     # for which "d" is zero, there is no box-line intersection.
    %if any((z(zero_d) < lb(zero_d) )==1) || any((z(zero_d) > ub(zero_d) )==1 )
    if any((z(zero_d) < lb(zero_d) ) ) || any((z(zero_d) > ub(zero_d) ) )
        % zero vector, outside boundary, then no intersection
        ta=0; tb=0; intersect=false;
        return;
    end
%     # Remove values for which d is zero
    %not_zero_d = np.logical_not(zero_d);
    not_zero_d = ~zero_d;
    z = z(not_zero_d);
    d = d(not_zero_d);
    lb = lb(not_zero_d);
    ub = ub(not_zero_d);
%     # Find a series of intervals (t_lb[i], t_ub[i]).
    t_lb = (lb-z) ./ d;
    t_ub = (ub-z) ./ d;
%     # Get the intersection of all those intervals.
    %ta = max(np.minimum(t_lb, t_ub)); %t_lb column???? TODO
    %tb = min(np.maximum(t_lb, t_ub));
    ta = max(min([t_lb'; t_ub'])); %t_lb column???? TODO
    tb = min(max([t_lb'; t_ub']));

%     # Check if intersection is feasible
    if ta <= tb
        intersect = true;
    else
        intersect = false;
    end
%     # Checks to see if intersection happens within vectors length.
    if ~entire_line
        if tb < 0 || ta > 1
            intersect = false;
            ta = 0;
            tb = 0;
        else
%             # Restrict intersection interval between 0 and 1.
            ta = max(0, ta);
            tb = min(1, tb);
        end
    end
end

%function box_sphere_intersections(z, d, lb, ub, trust_radius,entire_line=False,extra_info=False)
function [ta, tb, intersect, sphere_info, box_info]=box_sphere_intersections(z, d,...
    lb, ub, trust_radius,entire_line,extra_info)
%     """Find the intersection between segment (or line) and box/sphere constraints.
% 
%     Find the intersection between the segment (or line) defined by the
%     parametric  equation ``x(t) = z + t*d``,  the rectangular box
%     ``lb <= x <= ub`` and the ball ``||x|| <= trust_radius``.
% 
%     Parameters
%     ----------
%     z : array_like, shape (n,)
%         Initial point.
%     d : array_like, shape (n,)
%         Direction.
%     lb : array_like, shape (n,)
%         Lower bounds to each one of the components of ``x``. Used
%         to delimit the rectangular box.
%     ub : array_like, shape (n, )
%         Upper bounds to each one of the components of ``x``. Used
%         to delimit the rectangular box.
%     trust_radius : float
%         Ball radius.
%     entire_line : bool, optional
%         When ``True`` the function returns the intersection between the line
%         ``x(t) = z + t*d`` (``t`` can assume any value) and the constraints.
%         When ``False`` returns the intersection between the segment
%         ``x(t) = z + t*d``, ``0 <= t <= 1`` and the constraints.
%     extra_info : bool, optional
%         When ``True`` returns ``intersect_sphere`` and ``intersect_box``.
% 
%     Returns
%     -------
%     ta, tb : float
%         The line/segment ``x(t) = z + t*d`` is inside the rectangular box and
%         inside the ball for for ``ta <= t <= tb``.
%     intersect : bool
%         When ``True`` there is a intersection between the line (or segment)
%         and both constraints. On the other hand, when ``False``, there is no
%         intersection.
%     sphere_info : dict, optional
%         Dictionary ``{ta, tb, intersect}`` containing the interval ``[ta, tb]``
%         for which the line intercept the ball. And a boolean value indicating
%         whether the sphere is intersected by the line.
%     box_info : dict, optional
%         Dictionary ``{ta, tb, intersect}`` containing the interval ``[ta, tb]``
%         for which the line intercept the box. And a boolean value indicating
%         whether the box is intersected by the line.
%     """
    [ta_b, tb_b, intersect_b] = box_intersections(z, d, lb, ub,entire_line);
    [ta_s, tb_s, intersect_s] = sphere_intersections(z, d,trust_radius,entire_line);
    ta = max([ta_b, ta_s]);
    tb = min([tb_b, tb_s]);
    if intersect_b && intersect_s && ta <= tb
        intersect = true;
    else
        intersect = false;
    end

    if extra_info
        %sphere_info = {'ta': ta_s, 'tb': tb_s, 'intersect': intersect_s}
        %box_info = {'ta': ta_b, 'tb': tb_b, 'intersect': intersect_b}
        sphere_info = {};
        sphere_info{1} = ta_s; sphere_info{2} = tb_s; sphere_info{3} = intersect_s;
        box_info = {};
        box_info{1} = ta_b; box_info{2} = tb_b; box_info{3} = intersect_b;
        return;
    else
        sphere_info = {};
        box_info = {};
        return;
    end
end

function flag=inside_box_boundaries(x, lb, ub)
%     """Check if lb <= x <= ub."""
    flag= ( all(lb <= x) && all(x <= ub) );
end

function y = reinforce_box_boundaries(x, lb, ub)
%     """Return clipped value of x"""
    y= min([max([x'; lb']); ub']); % y is row vector
    y = y';
end

function x = modified_dogleg(A, b, trust_radius, lb, ub)
%%%%%%%%%%%%%% test dogleg
%             in_A = diag([1,1]);
%             in_b = [0;0]
%             lb = [-1;-1];
%             ub = [1;1];
%             tild_v = modified_dogleg(in_A, in_b, 0.1, lb, ub);
%             tild_v   % returns zero vector, seems OK
%%%%%%%%%%%%%%%%%%
%     """Approximately  minimize ``1/2*|| A x + b ||^2`` inside trust-region.
%     1/2*|| A x + b ||^2 = 0.5x'A'Ax+b'Ax+0.5*b'b
%     Approximately solve the problem of minimizing ``1/2*|| A x + b ||^2``
%     subject to ``||x|| < Delta`` and ``lb <= x <= ub`` using a modification
%     Delta = trust_radius, I noted
%     of the classical dogleg approach.
% 
%     Parameters
%     ----------
%     A : LinearOperator (or sparse matrix or ndarray), shape (m, n)
%         Matrix ``A`` in the minimization problem. It should have
%         dimension ``(m, n)`` such that ``m < n``.
%     Y : LinearOperator (or sparse matrix or ndarray), shape (n, m)
%         LinearOperator that apply the projection matrix
%         ``Q = A.T inv(A A.T)`` to the vector.  The obtained vector
%         ``y = Q x`` being the minimum norm solution of ``A y = x``.
%     b : array_like, shape (m,)
%         Vector ``b``in the minimization problem.
%     trust_radius: float
%         Trust radius to be considered. Delimits a sphere boundary
%         to the problem.
%     lb : array_like, shape (n,)
%         Lower bounds to each one of the components of ``x``.
%         It is expected that ``lb <= 0``, otherwise the algorithm
%         may fail. If ``lb[i] = -Inf`` the lower
%         bound for the i-th component is just ignored.
%     ub : array_like, shape (n, )
%         Upper bounds to each one of the components of ``x``.
%         It is expected that ``ub >= 0``, otherwise the algorithm
%         may fail. If ``ub[i] = Inf`` the upper bound for the i-th
%         component is just ignored.
% 
%     Returns
%     -------
%     x : array_like, shape (n,)
%         Solution to the problem.
% 
%     Notes
%     -----
%     Based on implementations described in p.p. 885-886 from [1]_.
% 
%     References
%     ----------
%     .. [1] Byrd, Richard H., Mary E. Hribar, and Jorge Nocedal.
%            "An interior point algorithm for large-scale nonlinear
%            programming." SIAM Journal on Optimization 9.4 (1999): 877-900.
%     """
    % Compute minimum norm minimizer of 1/2*|| A x + b ||^2.
    %Y=A.T inv(A A.T)
    %newton_point = -Y.dot(b);
    newton_point = - A'*( (A*A')\b ); %% OK? TODO
    % Check for interior point
    if inside_box_boundaries(newton_point, lb, ub)  &&  norm(newton_point) <= trust_radius
        x = newton_point;
        return;
    end  % different from 1999, TODO

    % Compute gradient vector ``g = A.T b``
    g = A'*b;
    % Compute cauchy point
    % `cauchy_point = g.T g / (g.T A.T A g)``.
    A_g = A*g;
    cauchy_point = -g'*g / (A_g'*A_g) * g;
    % Origin
    origin_point = zeros( size(cauchy_point) );

    % Check the segment between cauchy_point and newton_point
    % for a possible solution.
    z = cauchy_point;
    p = newton_point - cauchy_point;
    [~, alpha, intersect] = box_sphere_intersections(z, p, lb, ub,trust_radius,false,false);
    if intersect
        x1 = z + alpha*p;
    else
        % Check the segment between the origin and cauchy_point
        % for a possible solution.
        z = origin_point;
        p = cauchy_point;
        [~, alpha, ~] = box_sphere_intersections(z, p, lb, ub,trust_radius,false,false);
        x1 = z + alpha*p;
    end

    % Check the segment between origin and newton_point
    % for a possible solution.
    z = origin_point;
    p = newton_point;
    [~, alpha, ~] = box_sphere_intersections(z, p, lb, ub,trust_radius,false,false);
    x2 = z + alpha*p;
    % Return the best solution among x1 and x2.
    if norm(A*x1 + b) < norm(A*x2 + b)
        x = x1;
        return;
    else
        x = x2;
        return;
    end
end

% function [PA] = getPrOperator(A,A_row,A_col)
%     A_ext = [eye(A_col), A';
%         A,zeros([A_row,A_row])];
%     PA = decomposition(A_ext);
% end
% 
% function [proj] = getPrfromPA(PA,r,A_row,A_col) % Pr
%     % compute g=Pr, where P = I-A'(AA')^{-1} A, 
%     % Ax+b = 0.
%     zero_dim = A_row+A_col-size(r,1);
%     zero_vec = zeros([zero_dim,1]);
%     fac = PA\[r;zero_vec];
%     proj = fac(1:A_col,1);
% end

function [proj] = getPr(A,r) % Pr
    % compute g=Pr, where P = I-A'(AA')^{-1} A, 
    % Ax+b = 0.
    [A_row,A_col]=size(A);
    A_ext = [eye(A_col), A';
        A,zeros([A_row,A_row])];
    zero_dim = A_row+A_col-size(r,1);
    zero_vec = zeros([zero_dim,1]);
    
    fac = A_ext\[r;zero_vec];
    proj = fac(1:A_col,1);
end


function allvecs = projected_cg(H, c, A, b, trust_radius, lb, ub)
%             in_A = diag([1,1]);
%             in_b = [-0.5;-0.5];
%             H = diag([10,10]);
%             c = [0;0];
%             lb = [0.5;0.5];
%             ub = [1;1];
%             allvec = projected_cg(H, c, in_A, in_b, 100, lb, ub)
%             % allvec len zero, infeasible
%             % allvec{1} % possible empty, empty, infeasible
%             % other situations give correct results
% function x = projected_cg(H, c, Z, Y, b, trust_radius, lb, ub, tol,...
%                  max_iter, max_infeasible_iter, return_all)
%     """Solve EQP problem with projected CG method.
% 
%     Solve equality-constrained quadratic programming problem
%     ``min 1/2 x.T H x + x.t c``  subject to ``A x + b = 0`` and,
%     possibly, to trust region constraints ``||x|| < trust_radius``
%     and box constraints ``lb <= x <= ub``.
% 
%     Parameters
%     ----------
%     H : LinearOperator (or sparse matrix or ndarray), shape (n, n)
%         Operator for computing ``H v``.
%     c : array_like, shape (n,)
%         Gradient of the quadratic objective function.
%     Z : LinearOperator (or sparse matrix or ndarray), shape (n, n)
%         Operator for projecting ``x`` into the null space of A.
%     Y : LinearOperator,  sparse matrix, ndarray, shape (n, m)
%         Operator that, for a given a vector ``b``, compute smallest
%         norm solution of ``A x + b = 0``.
%     b : array_like, shape (m,)
%         Right-hand side of the constraint equation.
%     trust_radius : float, optional
%         Trust radius to be considered. By default uses ``trust_radius=inf``,
%         which means no trust radius at all.
%     lb : array_like, shape (n,), optional
%         Lower bounds to each one of the components of ``x``.
%         If ``lb[i] = -Inf`` the lower bound for the i-th
%         component is just ignored (default).
%     ub : array_like, shape (n, ), optional
%         Upper bounds to each one of the components of ``x``.
%         If ``ub[i] = Inf`` the upper bound for the i-th
%         component is just ignored (default).
%     tol : float, optional
%         Tolerance used to interrupt the algorithm.
%     max_iter : int, optional
%         Maximum algorithm iterations. Where ``max_inter <= n-m``.
%         By default uses ``max_iter = n-m``.
%     max_infeasible_iter : int, optional
%         Maximum infeasible (regarding box constraints) iterations the
%         algorithm is allowed to take.
%         By default uses ``max_infeasible_iter = n-m``.
%     return_all : bool, optional
%         When ``true`` return the list of all vectors through the iterations.
% 
%     Returns
%     -------
%     x : array_like, shape (n,)
%         Solution of the EQP problem.
%     info : Dict
%         Dictionary containing the following:
% 
%             - niter : Number of iterations.
%             - stop_cond : Reason for algorithm termination:
%                 1. Iteration limit was reached;
%                 2. Reached the trust-region boundary;
%                 3. Negative curvature detected;
%                 4. Tolerance was satisfied.
%             - allvecs : List containing all intermediary vectors (optional).
%             - hits_boundary : True if the proposed step is on the boundary
%               of the trust region.
% 
%     Notes
%     -----
%     Implementation of Algorithm 6.2 on [1]_.
% 
%     In the absence of spherical and box constraints, for sufficient
%     iterations, the method returns a truly optimal result.
%     In the presence of those constraints the value returned is only
%     a inexpensive approximation of the optimal value.
% 
%     References
%     ----------
%     .. [1] Gould, Nicholas IM, Mary E. Hribar, and Jorge Nocedal.
%            "On the solution of equality constrained quadratic
%             programming problems arising in optimization."
%             SIAM Journal on Scientific Computing 23.4 (2001): 1376-1395.
%     """
    CLOSE_TO_ZERO = 1e-25;

    n = size(c,1); % # Number of parameters
    m = size(b,1);  %# Number of constraints

    %# Initial Values
    %x = Y.dot(-b);   
    % Ax+b=0, original paper is Ax=b
    x = - A'*( (A*A')\b ); % Yx = A'*( (A*A') x), TODO  book 2001, page 6
    %newton_point = - A'*( (A*A')\b ); %% OK? TODO
    %[A_row,A_col] = size(A);
    %PA = getPrOperator(A,A_row,A_col);
    
    %[proj] = getPrfromPA(PA,r,A_row,A_col)
    r = getPr(A,H*x + c); %r = getPrfromPA(PA,H*x + c,A_row,A_col);   %Z.dot(H*x + c); % P(Hx+c)
    g = getPr(A,r); %getPrfromPA(PA,r,A_row,A_col);  %getPr(A,r);    %Z.dot(r);  % Pr
    p = -g;

    %# Store ``x`` value
    allvecs = {};
    allvecs{1} = x;

    %# Values for the first iteration
    H_p = H*p;
    rt_g = norm(g)^2;  %# g.T g = r.T Z g = r.T g (ref [1]_ p.1389)

    %# If x > trust-region the problem does not have a solution.
    tr_distance = trust_radius - norm(x);
    if tr_distance < 0
        allvecs = {};  % indicate error
        return;
    end
    %# If x == trust_radius, then x is the solution
    %# to the optimization problem, since x is the
    %# minimum norm solution to Ax=b.  no cosider upper bounds?????? TODO ????
    if tr_distance < CLOSE_TO_ZERO % not smaller than zero
        %info = {'niter': 0, 'stop_cond': 2, 'hits_boundary': True};
        %info = {1: 0, 2: 2, 3: true};
        info = {1: 0, 2: 2, 3: 1};
%         if return_all
%             allvecs.append(x);
%             info['allvecs'] = allvecs;
%         end
        allvecs{1} = x;
        allvecs{2} = info;
        return;
    end

    %# Set default tolerance
    tol = max(min(0.01 * sqrt(rt_g), 0.1 * rt_g), CLOSE_TO_ZERO);
    %# Set default lower and upper bounds
    if isempty(lb)
        %lb = np.full(n, -Inf);
        lb = -Inf*ones([n,1]); %np.full(n, -Inf);
    end
    if isempty(ub)  %  no input then input []
        ub = Inf*ones([n,1]);
    end
    %# Set maximum iterations
%     if isempty(max_iter)
%         max_iter = n-m;
%     end
%     max_iter = min(max_iter, n-m);
    max_iter = n-m;
    %# Set maximum infeasible iterations
    max_infeasible_iter = n-m;

    hits_boundary = 0; % false
    stop_cond = 1;
    counter = 0;
    %last_feasible_x = np.empty_like(x);
    %last_feasible_x = []; %OK? TODO
    last_feasible_x = zeros(size(x)); 
    %last_feasible_x = x;
    k = 0;
    %for i in range(max_iter)
    for i =1: max_iter
        % Stop criteria - Tolerance : r.T g < tol
        if rt_g < tol
            stop_cond = 4;
            break;
        end
        k = k+ 1;
        %# Compute curvature
        pt_H_p = H_p'*p;
        %# Stop criteria - Negative curvature
        if pt_H_p <= 0
            if trust_radius==Inf
                allvecs = {};
                return;
                %raise ValueError("Negative curvature not ""allowed for unrestrited ""problems.");
            else
                %# Find intersection with constraints
                [~, alpha, intersect] = box_sphere_intersections(x, p, lb, ub, trust_radius, true,false);
                %# Update solution
                if intersect
                    x = x + alpha*p;
                end
                %# Reinforce variables are inside box constraints.
                %# This is only necessary because of roundoff errors.
                x = reinforce_box_boundaries(x, lb, ub);
                %# Atribute information
                stop_cond = 3;
                hits_boundary = true;%true
                break;
            end
        end

        %# Get next step
        alpha = rt_g / pt_H_p;
        x_next = x + alpha*p;

        %# Stop criteria - Hits boundary
        if norm(x_next) >= trust_radius
            %# Find intersection with box constraints
            [~, theta, intersect] = box_sphere_intersections(x, alpha*p, lb, ub, trust_radius,false,false);
            %# Update solution
            if intersect
                x = x + theta*alpha*p;
            end
            %# Reinforce variables are inside box constraints.
            %# This is only necessary because of roundoff errors.
            x = reinforce_box_boundaries(x, lb, ub);
            %# Atribute information
            stop_cond = 2;
            hits_boundary = true; % true
            break;
        end

        %# Check if ``x`` is inside the box and start counter if it is not.
        if inside_box_boundaries(x_next, lb, ub)
            counter = 0;
        else
            counter = counter+1;
        end
        %# Whenever outside box constraints keep looking for intersections.
        if counter > 0
            [~, theta, intersect] = box_sphere_intersections(x, alpha*p, lb, ub,trust_radius,false,false);
            if intersect
                last_feasible_x = x + theta*alpha*p;
                %# Reinforce variables are inside box constraints.
                %# This is only necessary because of roundoff errors.
                last_feasible_x = reinforce_box_boundaries(last_feasible_x,lb, ub);
                counter = 0;
            end
        end
        %# Stop after too many infeasible (regarding box constraints) iteration.
        if counter > max_infeasible_iter
            break;
        end
        %# Store ``x_next`` value
%         if return_all   % bu return all
%             allvecs.append(x_next);
%         end

        %# Update residual
        r_next = r + alpha*H_p;
        %# Project residual g+ = Z r+
        %g_next = Z.dot(r_next);
        %g_next = getPrfromPA(PA,r_next,A_row,A_col);
        g_next = getPr(A,r_next);
        %# Compute conjugate direction step d
        rt_g_next = norm(g_next)^2;  %# g.T g = r.T g (ref [1]_ p.1389)
        beta = rt_g_next / rt_g;
        p = - g_next + beta*p;
        %# Prepare for next iteration
        x = x_next;
        g = g_next;
        r = g_next;
        rt_g = norm(g)^2;  %# g.T g = r.T Z g = r.T g (ref [1]_ p.1389)
        H_p = H*p;
    end

    if ~inside_box_boundaries(x, lb, ub)
        x = last_feasible_x;
        %x = reinforce_box_boundaries(last_feasible_x,lb, ub);
        hits_boundary = 1; %true
    end
    %info = {'niter': k, 'stop_cond': stop_cond,'hits_boundary': hits_boundary};
    info = {1: k, 2: stop_cond, 3: hits_boundary};
    allvecs{1} = x;
    allvecs{2} = info;
    return;
end
