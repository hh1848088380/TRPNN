clear;
clc;
close all;
warning off;
global ode_result dim_x xl xu RNN10_para TRU_para ODE_para epsilon;

ode_result=[];

num_pso=[1];%NN
M=4;%M
Moto=50;%随机次数

dim_x=2;


xl= [-1,-1]'; %约束下限
xu= [2,1]'; %约束上限


RNN10_para.MaxIter=20000;
RNN10_para.h=0.001;
RNN10_para.r=RNN10_para.h/2;
RNN10_para.theta=0.01;%0.01
RNN10_para.pro=2;
RNN10_para.inta=0.002;%0.002

TRU_para.MaxIter=1000;
TRU_para.dta=5;
TRU_para.dtamax=20;
TRU_para.eta1=0.25;
TRU_para.eta2=0.75;
TRU_para.gma1=0.5;
TRU_para.gma2=2;


ODE_para.tspan=[0 200]; %ode时间
ODE_para.sigma1=0.5;
ODE_para.sigma2=0.25;
ODE_para.c=1;
ODE_para.pl=0.5;
ODE_para.epsilon=1e-5;
ODE_para.sigma2sq=0.01;
ODE_para.sigma2sq=0.005;


methods= {'TRPNN','RNN5','RNN6','RNN7','RNN8','RNN9','RNN10','RNN11'};


for np=1:length(num_pso)
    NN=num_pso(np);
    rng('shuffle');
    init=unifrnd(-5,5,dim_x,NN,Moto);
    for i=1:Moto
        initt=init(:,:,i);
        for j=1:numel(methods)
            if NN==1
                [f_val, z_val, time, itr] = compare_fun(methods{j}, initt); %z是组合变量
                disp([methods{j},'-i=',num2str(i),';N=',num2str(NN)]);
            else
                [f_val, z_val, time, itr] = CNO_FUN(methods{j}, M, initt,i,NN);
            end
            eval([methods{j} '_x(:,i) = z_val(1:dim_x);']);
            eval([methods{j} '_f(i) = f_val;']);
            eval([methods{j} '_time(i) = time;']);
            if j==1 || j==2
                eval([methods{j} '_itr(i) = itr;']);
            end
        end
    end

    clear init;

end
disp('finish');
