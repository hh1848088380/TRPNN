function stats = odestatis(NN_f,NN_time)

stats.aver_f=mean(NN_f);
stats.std_f=std(NN_f);

stats.aver_time=mean(NN_time);
stats.std_time=std(NN_time);

end