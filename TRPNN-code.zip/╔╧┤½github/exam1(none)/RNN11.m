function [output,k] = RNN11(z0)
global APNN_para xl xu dim_x;
xk=z0(1:dim_x);

MaxIter=APNN_para.MaxIter;
h=APNN_para.h;
r=APNN_para.r;
theta=0;
pro=APNN_para.pro;
inta=APNN_para.inta;

%参数设置
smstep=1e-6;
k=1;
s(k)=h;
sumd=0;

store_x(:,k)=xk;
fk=oscalf(xk);  store_fk(k)=fk;

Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;



Glk=Gfk; store_Glk(:,k)=Glk;

pro_gk=-xk+xpro(xk-Glk,xl,xu);
store_pro_gk(:,k)=pro_gk;

while(k<MaxIter)
    %计算Euler函数值和梯度

    xk=xk+h*pro_gk;
    k=k+1;

    store_x(:,k)=xk;
    fk=oscalf(xk);  store_fk(k)=fk;
    Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;


    Glk=Gfk;
    pro_gk=-xk+xpro(xk-Glk,xl,xu);
    store_pro_gk(:,k)=pro_gk;


    hx=xk+0.5*s(k-1)*(store_pro_gk(:,k-1) + pro_gk);

    delta=norm([hx]-[xk]);

    sumd=sumd+delta;

    s(k)= ( r/(pro*delta+inta*sumd) )^(theta/2)*s(k-1);

    %判断终止条件 (norm(pro_gk)<err && norm(lamk'*gk)<1e-6 && norm(hk)<1e-6)
%     if norm([xk]-[store_x(:,k-1)])<1e-5
%         break;
%     end
    if norm(pro_gk)<1e-5
        break;
    end
end
    output=[xk];
end




% function [output,k,toltime] = PNN(maxit, epsilon, z, gamma, qamma,r1, theta,alpha,beta, pro,inta)
%
%     global LL  delta h;
%     cputime=[];
%     l=1;
%
%     nN=6;
%     x(:,1)=z(1:nN);
%     lamb(:,1)=z(nN+1:2*nN);
%     eta(:,1)=z(2*nN+1:3*nN);
%     k=1;
%
%     gamma=1;
%     qamma=1;
%  [f(:,k),g(:,k),graf(:,k),grag(:,:,k)]=oscal(x(:,k));
%  xbpro(:,k)=x(:,k)-graf(:,k)-gamma*grag(:,:,k)'*lamb(:,k)-LL*(x(:,k)+eta(:,k))-alpha*grag(:,:,k)'*diag(lamb(:,k).^2)*g(:,k);
%  xapro(:,k)=xpro(xbpro(:,k));
%  gbpro(:,k)=lamb(:,k)+gamma*g(:,k);
%  gapro(:,k)=gpro(gbpro(:,k));
%
% dimv(1)=norm(z);
% theta=0;
% while 1
%     tic;
%    %%Euler
%     x(:,k+1)=x(:,k)+h(k)*(-x(:,k)+xapro(:,k));
%     lamb(:,k+1)=lamb(:,k)+h(k)*(-lamb(:,k)+gapro(:,k));
%     eta(:,k+1)=eta(:,k)+h(k)*(qamma*LL*x(:,k));
%
%     %%Heun
%     [f(:,k+1),g(:,k+1),graf(:,k+1),grag(:,:,k+1)]=oscal(x(:,k+1));
%     xbpro(:,k+1)=x(:,k+1)-graf(:,k+1)-gamma*grag(:,:,k+1)'*lamb(:,k+1)-LL*(x(:,k+1)+eta(:,k+1))-alpha*grag(:,:,k+1)'*diag(lamb(:,k+1).^2)*g(:,k+1);
%     xapro(:,k+1)=xpro(xbpro(:,k+1));
%     gbpro(:,k+1)=lamb(:,k+1)+gamma*g(:,k+1);
%     gapro(:,k+1)=gpro(gbpro(:,k+1));
%
%     hx(:,k+1)=x(:,k)+0.5*h(k)*(-x(:,k)+xapro(:,k)-x(:,k+1)+xapro(:,k+1));
%     hlamb(:,k+1)=lamb(:,k)+0.5*h(k)*(-lamb(:,k)+gapro(:,k)-lamb(:,k+1)+gapro(:,k+1));
%     heta(:,k+1)=eta(:,k)+0.5*h(k)*(qamma*LL*x(:,k)+qamma*LL*x(:,k+1));
%
%
%     delta(:,k)=norm([hx(:,k+1);hlamb(:,k+1);heta(:,k+1)]-[x(:,k+1);lamb(:,k+1);eta(:,k+1)]);
%
%         if k==1
%             sumd(:,k)=delta(:,k);
%         else
%             sumd(:,k)=sumd(:,k-1)+delta(:,k);
%         end
%     h(k+1)= ( r1/(pro*delta(:,k)+inta*sumd(:,k)) )^(theta/2)*h(k);
%
%
%         dimv(k)=norm([x(:,k+1);lamb(:,k+1);eta(:,k+1)]-[x(:,k);lamb(:,k);eta(:,k)]);
%         if k>maxit || dimv(k)<epsilon
%             break;
%         end
%
%     cputime(l)=toc;
%     l=l+1;
%     k=k+1;
% end
%     toltime=sum(cputime);
%     output = [x; lamb; eta];
%
%
% end




