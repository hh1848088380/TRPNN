function max_vio=get_constraint_violation(x,h,g,x_up,x_low)
v = [abs(h(x)),max(g(x),0),max(x-x_up,0)',max(x_low-x,0)'];
max_vio = max(v);
end

