function [h, secH ]= oscalh(x)
%% R6-->R4
    x1=x(1); x2=x(2); x3=x(3); x4=x(4); x5=x(5); x6=x(6);
    secH=zeros(6,6,4);
    k1=0.09755988; k2=0.99*k1; k3=0.0391908; k4=0.9*k3;
    h1=x1+k1*x1*x5-1;
    h2=x2-x1+k2*x2*x6;
    h3=x3+x1+k3*x3*x5-1;
    h4=x4-x3+x2-x1+k4*x4*x6;
    h=[h1, h2, h3, h4]';
    secH(1,5,1)=k1; secH(5,1,1)=k1;
    secH(2,6,2)=k2; secH(6,2,2)=k2;
    secH(3,5,3)=k3; secH(5,3,3)=k3;
    secH(4,6,4)=k4; secH(6,4,4)=k4;
end

