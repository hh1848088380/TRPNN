function dot_all = ODEPNN(t,z,method)
global xl xu ODE_para dim_x dim_l dim_m;

sigma1 = ODE_para.sigma1;
sigma2 = ODE_para.sigma2;
sigma1sq = ODE_para.sigma2sq;
sigma2sq = ODE_para.sigma2sq;
s=ODE_para.arg;
alpha = ODE_para.alpha;
beta = ODE_para.beta;
c = ODE_para.c;
pl = ODE_para.pl;

x=z(1:dim_x);

if ~strcmp(method, 'onePNN')
    lamb=z(dim_x+1:dim_x+dim_l);
    mu=z(dim_x+dim_l+1:dim_x+dim_l+dim_m);
end


smstep=1e-6;

g=oscalg(x);
h=oscalh(x);
graf=oscalGf(x,smstep);
grag=oscalGg(x,smstep);
grah=oscalGh(x,smstep);
switch method
    case 'argPNN'
        dotx= s*(-x+xpro(x-graf-grag*lamb-grah*mu-alpha*grag*diag(lamb.^2)*g-beta*grah*diag(mu.^2)*h,xl,xu));
        dotlamb= s*(-lamb + xpro(lamb+g+alpha*diag(lamb)*g.^2,0,inf));
        dotmu = s*(h + beta*diag(mu)*h.^2); 
        dot_all=[dotx; dotlamb; dotmu];
    case 'ttPNN'
        dotx = (1/sigma1)*(-x+xpro(x-graf-grag*lamb-grah*mu,xl,xu)) ;
        dotlamb= (1/sigma2)*(-lamb + xpro(lamb+g,0,inf)) ;
        dotmu = (1/sigma2)*h;
        dot_all=[dotx; dotlamb; dotmu];
    case 'mmPNN'
        zx=z(dim_x+dim_l+dim_m+1:end);
        grafz=oscalGf(zx,smstep);
        grafzx=grafz+c*(zx-x);
        dotx = (1/sigma1)*(zx-x);
        dotzx = (1/sigma2)*(-zx+xpro(zx-grafzx-grag*lamb-grah*mu,xl,xu));
        dotlamb= (1/sigma2)*(-lamb + xpro(lamb + grag'*(zx-x) + g,0,inf) );
        dotmu = (1/sigma2)*(h+grah'*(zx-x));
        dot_all=[dotx; dotlamb; dotmu; dotzx];
    case 'sqPNN'
        y=z(dim_x+dim_l+1:end);
        Q=oscalHess(x,smstep);
        dotx = (1/sigma1sq)*y;
        doty = (1/sigma2sq)*(-y + xpro( y-y-graf - grag*lamb ,xl,xu));
        dotlamb = (1/sigma2sq)*(-lamb + xpro(lamb + grag'*y + g ,0,inf));
         
        dot_all=[dotx;  dotlamb; doty];
    case 'onePNN'
        one_grag=one_oscalGg(x,smstep);
        one_g=one_oscalg(x);
        delta_g=zeros(size(one_grag));
        indices = find(one_g >= 0);
        delta_g(:,indices) = one_grag(:,indices);
        dotx= (1/sigma2sq)*(-graf-(1/pl)*sum(delta_g,2));
        dot_all=dotx;
end

t;
end