function grad = oscalGh(x,smstep)
    x_len=length(x); %%变量个数
        for i=1:x_len
            xp=x; xm=x;
            xp(i)=x(i)+smstep;
            xm(i)=x(i)-smstep;
            grad(:,i)=(oscalh(xp)-oscalh(xm))/(2*smstep);
        end
%     end
    grad=grad';
end

