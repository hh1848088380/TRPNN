function [output,k] = trustPNN(z0)
global TRU_para xl xu dim_x dim_l dim_m;
xk=z0(1:dim_x);
lamk=z0(dim_x+1:dim_x+dim_l);
muk=z0(dim_x+dim_l+1:dim_x+dim_l+dim_m);

MaxIter=TRU_para.MaxIter;
alpha=TRU_para.alpha;
beta=TRU_para.beta;
dta=TRU_para.dta;
dtamax=TRU_para.dtamax;
eta1=TRU_para.eta1;
eta2=TRU_para.eta2;
gma1=TRU_para.gma1;
gma2=TRU_para.gma2; 
sh=TRU_para.sh;

k=1;
cou=0;
err=1e-6; smstep=1e-8;
while(k<MaxIter)
    %计算函数值和梯度
    store_x(:,k)=xk;
    store_lam(:,k)=lamk;

    fk=oscalf(xk);  store_fk(k)=fk;
    gk=oscalg(xk);  store_gk(:,k)=gk;
    [hk, sechk]=oscalh(xk);  store_hk(:,k)=hk;

    Gfk=oscalGf(xk,smstep);  store_Gfk(:,k)=Gfk;
    Ggk=oscalGg(xk,smstep);  store_Ggk(:,:,k)=Ggk;
    Ghk=oscalGh(xk,smstep);  store_Ghk(:,:,k)=Ghk;

    HsumgGg=zeros(length(xk));
    for i=1:length(gk)
        gGgk(:,i)=lamk(i)^2*gk(i)*Ggk(:,i);%一阶梯度

        HgGgk(:,:,i)=lamk(i)^2*Ggk(:,i)*Ggk(:,i)';%二阶梯度
        HsumgGg=HsumgGg+HgGgk(:,:,i);
    end

    HsumgGh=zeros(length(xk));
    for i=1:length(hk)
        gGhk(:,i)=muk(i)^2*hk(i)*Ghk(:,i);%一阶梯度
        SecHk(:,:,i)=muk(i)*sechk(:,:,i);

        HgGhk(:,:,i)=muk(i)^2*Ghk(:,i)*Ghk(:,i)';%二阶梯度
        HsumgGh=HsumgGh+HgGhk(:,:,i);
    end

    Glk=Gfk+Ggk*lamk+Ghk*muk+alpha*sum(gGgk,2)+beta*sum(gGhk,2);
%     Glk=Gfk+Ggk*lamk+Ghk*muk+alpha*Ggk*diag(lamk.^2)*gk+beta*Ghk*diag(muk.^2)*hk;
    store_Glk(:,k)=Glk;
    Bk=oscalHess(xk,smstep)+alpha*HsumgGg+beta*(HsumgGh+sum(SecHk,3));
    store_Bk(k)=min(eig(Bk));
    %狗腿法求解二次近似子问题
    dk=dogleg(Glk,Bk,dta);
    store_dk(:,k)=dk;

    %投影约束
    pro_dk=-xk+xpro(xk+dk,xl,xu);
    store_pro_dk(:,k)=pro_dk;


    pro_gk=-xk+xpro(xk-Glk,xl,xu);
    store_pro_gk(:,k)=pro_gk;

    t=1;
    dtr=t*pro_dk+(1-t)*pro_gk;
    store_dtr(:,k)=dtr;

    %判断终止条件
        if ( norm(dtr)<err && norm(gk,inf)<err && norm(hk)<err)
%             disp(fk);
%             disp('succ');
            break;
        end

    %计算下降效果
    deltaq = -(Glk'*dtr+0.5*dtr'*Bk*dtr);
    oscalL = oscalf(xk)+ lamk'*oscalg(xk) + muk'*oscalh(xk) + alpha*0.5*sum((lamk.*oscalg(xk)).^2) + beta*0.5*sum((muk.*oscalh(xk)).^2);
    oscalLd = oscalf(xk+dtr)+lamk'*oscalg(xk+dtr) + muk'*oscalh(xk+dtr) + alpha*0.5*sum((lamk.*oscalg(xk+dtr)).^2) + beta*0.5*sum((muk.*oscalh(xk+dtr)).^2);
    deltaf = oscalL-oscalLd;
    rhok = deltaf/deltaq;
    store_rhok(k) = rhok;

    %根据下降效果，更新信赖域
    if rhok<=eta1 || deltaq<=0
        dta = gma1*dta;
        xk=xk+sh*pro_gk;
        lamk=lamk+sh*(-lamk+xpro(lamk+gk+alpha*diag(lamk)*gk.^2,0,inf));
        muk=muk+sh*(hk+beta*diag(muk)*hk.^2);
        cou=cou+1;
        store_dta(k)=dta;
        continue;
    end

    if rhok >= eta1 && rhok <= eta2
        dta = dta;
    end

    if rhok > eta2
        dta=min(gma2*dta,dtamax);
    end
    store_dta(k)=dta;
    xk=xk+sh*dtr;
    lamk=lamk+sh*(-lamk+xpro(lamk+gk+alpha*diag(lamk)*(gk.^2),0,inf));
    muk=muk+sh*(hk+beta*diag(muk)*(hk.^2));
%     lamk=lamk+1*(-lamk+xpro(lamk+gk,0,inf));
%     muk=muk+1*(hk);
    k=k+1;
end
    output=[xk;lamk;muk];
end

