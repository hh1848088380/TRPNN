function [f_val, z_val, time, itr] = compare_fun(method,z0)
global ODE_para dim_x dim_l dim_m ode_result;
tspan = ODE_para.tspan;
epsilon = ODE_para.epsilon;

timeout=unifrnd(160,161,1);

tic;
switch method
    case 'trustPNN'
        [z_val, itr] = trustPNN(z0);
    case 'APNN'
        [z_val, itr] = APNN(z0);
    case {'sqPNN'}
        sqz = [z0(1:dim_x); zeros(dim_x,1); z0(dim_x+1:end);];
        [z_val, sqtime]= TEST_TwoTimescale_Nonvex();
        itr=nan;
    case {'argPNN', 'ttPNN', 'mmPNN', 'onePNN'}
        if strcmp(method, 'argPNN')
            tspan = 1 * tspan;
        end
        if strcmp(method, 'mmPNN') 
            z0 = [z0; rands(dim_x,1)];
        end
        if strcmp(method, 'onePNN')
            z0 = z0(1:dim_x);
        end
        ode_result = [];
        op = odeset('Events', @(t,z) eventfun(t, z, epsilon));
        [t, ode_z] = ode45_timeout(tspan, z0, op, timeout, method);
        z_val=ode_z(end,:)';
        itr=nan;
end
time=toc;

switch method
    case {'mmPNN'}
        z_val=z_val(1:dim_x+dim_l+dim_m);

    case {'sqPNN'}
        time=sqtime;
        z_val=[z_val;zeros(dim_l,1);zeros(dim_m,1)];

    case {'onePNN'}
        z_val=[z_val;zeros(dim_l,1);zeros(dim_m,1)];

end




f_val=oscalf(z_val(1:dim_x));

end

