function dk= dogleg(gk,Bk,dta)
    pB=-Bk\gk; %全局最优点
    pU=-gk'*gk/(gk'*Bk*gk)*gk; %最降向全局最优点

    if norm(pB)<=dta
        dk=pB;
    elseif norm(pU)>dta
        dk=-dta/norm(gk)*gk;
    else
        pBU=pB-pU;
        tau_1=(sqrt( (pU'*pBU)^2-pBU'*pBU*(pU'*pU-dta^2) )-pU'*pBU)/(pBU'*pBU);
        dk=pU+tau_1*pBU;
    end
end

