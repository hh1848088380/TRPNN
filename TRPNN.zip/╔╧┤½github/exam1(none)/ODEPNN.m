function dot_all = ODEPNN(t,z,method)
global xl xu ODE_para dim_x;

sigma1 = ODE_para.sigma1;
sigma2 = ODE_para.sigma2;
sigma1sq = ODE_para.sigma2sq;
sigma2sq = ODE_para.sigma2sq;

c = ODE_para.c;
pl = ODE_para.pl;

x=z(1:dim_x);


smstep=1e-6;

graf=oscalGf(x,smstep);
switch method
    case 'argPNN'
        dotx= -x+xpro(x-graf,xl,xu);
        dot_all=[dotx;];
    case 'ttPNN'
        dotx = (-x+xpro(x-graf,xl,xu)) ;
        dot_all=[dotx;];
    case 'mmPNN'
        zx=z(dim_x+1:end);
        grafz=oscalGf(zx,smstep);
        grafzx=grafz+c*(zx-x);
        dotx = (1/sigma1)*(zx-x);
        dotzx = (1/sigma2)*(-zx+xpro(zx-grafzx,xl,xu));
        dot_all=[dotx; dotzx];
    case 'sqPNN'
        y=z(dim_x+dim_l+1:end);
        Q=oscalHess(x,smstep);
        dotx = (1/sigma1sq)*y;
        doty = (1/sigma2sq)*(-y + xpro( y-y-graf - grag*lamb ,xl,xu));
        dotlamb = (1/sigma2sq)*(-lamb + xpro(lamb + grag'*y + g ,0,inf));
         
        dot_all=[dotx;  dotlamb; doty];
    case 'onePNN'
        one_grag=one_oscalGg(x,smstep);
        one_g=one_oscalg(x);
        delta_g=zeros(size(one_grag));
        indices = find(one_g >= 0);
        delta_g(:,indices) = one_grag(:,indices);
        dotx=-graf-(1/pl)*sum(delta_g,2);
        dot_all=dotx;
end

t;
end