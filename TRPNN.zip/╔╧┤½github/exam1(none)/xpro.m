function apro = xpro(x,l,u)
    apro=max(min(x,u),l);
end