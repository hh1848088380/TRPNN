function [value,isterminal,direction] = eventfun(t,z,epsilon)
    global ode_result
    ode_result=[ode_result z]; 

    if  size(ode_result,2)==1
        value = abs(ode_result - 0) - epsilon;
    else
        value = norm(ode_result(:,end)-ode_result(:,end-1)) - epsilon;
    end
    
    isterminal=1;
    direction=0;
end

