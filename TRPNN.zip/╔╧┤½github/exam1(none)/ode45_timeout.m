function [t, ode_z] = ode45_timeout(tspan, z0, op, timeout, method)
    % 记录开始时间
    startTime = tic;

    % 自定义输出函数来检查超时
    function status = odeOutputFcn(t, y, flag)
        if toc(startTime) > timeout
            warning('Integration terminated due to timeout.');
            status = 1; % 终止ode45
        else
            status = 0; % 继续运行ode45
        end
    end

    % 将自定义输出函数加入 options 中
    if isempty(op)
        op = odeset();
    end
    op = odeset(op, 'OutputFcn', @odeOutputFcn);

    % 运行ode45
    [t, ode_z] = ode45(@(t,z) ODEPNN(t, z, method), tspan, z0, op);
end
